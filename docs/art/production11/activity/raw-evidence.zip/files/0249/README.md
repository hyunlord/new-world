# P11 capture preparation (external mirror; not yet runtime verified)

Install only the explicitly listed `scripts/test/art` and `tools/art_pipeline` files, excluding `__pycache__`. `p11_activity_oracle/*` are byte-identical `oracle-code-v2/*` from the P10 raw evidence ZIP. Keep the existing Part 0 `prepare_blind_crops_p11.py` untouched as archival copy; use `plan_activity_blind_p11.py` for the stricter P11 selection protocol.

## Scheduling

No cargo or Godot was launched during preparation. Every actual launch needs the leader's quiet-lock availability checks and existing window wrapper. Use a worktree with release bridge copied onto debug loading path and imports complete. The activity runner refuses differing release/debug dylib SHA256.

## Probe

Build: `CARGO_BUILD_JOBS=6 cargo build --release -p sim-test --bin worldsim_probe`.

Bound to 1800 seconds using `run_bounded.sh`, then launch `rust/target/release/worldsim_probe --scene game_v24 --seeds 20261011..20261027 --days 60 --workers 4 --clock-samples 10:00 --out <NEW_PROBE_DIR>`.

Rank only successfully completed `sample_kind=day, day=60, tick=86400` rows by alive descending then seed ascending. The range is exclusive at the upper end, so 16 seeds. Calendar day60 10:00 capture tick is 85080, separate from ranking endpoint. Preserve build/probe exit, timeout, completed and incomplete seeds. No reusable selection evaluator was found in repository. Prior evaluator output is in P10 archive `activities-part2-attempt2/selection-evidence`.

## Main six activity captures

`P11_DEADLINE_EPOCH=<epoch> python3 tools/art_pipeline/run_activity_captures_p11.py <CHECKOUT> <NEW_CAPTURE_DIR> <WINNING_SEED> <SELECTION_JSON>`

Cases: d30 10, d30 15 live seed, d60 10 populous seed; each Z4/Z1. Copied capture metadata and v2 pose oracle remain unchanged; new `draw_rects` includes all visible agent/building sprites sorted by `(z_index, world_y, sibling_index)` in y-sorted WorldObjects. Rectangle unions count overlapping blockers once. This is sprite-rectangle coverage, not alpha-pixel coverage.

Sidecar oracle: `python3 tools/art_pipeline/p11_activity_oracle/check_activity_sidecars.py <CHECKOUT> <CAPTURE_JSON>... > <POSE_REPORT_JSON>`.

Blind c: `python3 tools/art_pipeline/plan_activity_blind_p11.py <CHECKOUT> <NEW_BLIND_DIR> <D30_10_Z4_JSON> <D30_15_Z4_JSON> <D60_10_Z4_JSON> [ADDED_JSON...]`.

The planner refuses incorrect base order and non-Z4 frames, checks every holder through original pose oracle, chooses first two eligible arrived holders in AgentId order per capture, writes exclusions before any crops, then extracts the exact legacy crop: ceil(max(sprite width,height)+16), centered on sprite, 4x nearest display. Missing kinds produce an exclusion log and exit1 without crops.

For missing kinds, prerecord requested additions before launch. Set P11_ACTIVITY_OUT/SEED/DAY/HOUR/ZOOM and P11_ACTIVITY_CENTER_KIND (0..6), launch capture_activities_p11.gd using `with_window_lock.sh`, `--fixed-fps 60 --resolution 1920x1080`. Hours 11 and14 only. It centers on lowest AgentId arrived holder of that kind; record absent-holder failure rather than substituting another scene. Append these sidecars after base captures and use a NEW output directory. Runner does not automate added captures.

## Blind d

After c reviewer answer file is frozen, run `python3 tools/art_pipeline/prepare_activity_villages_p11.py <C_ANSWERS_JSON> <NEW_D_DIR> <Z1_JSON>...`.

Six pairs maximum two per village, skip top-two ties, only visible inside-frame summaries. It stores c-answer SHA256 before creating question crops. If fewer than six eligible pairs exist it writes incomplete key and exits1, never pads or fabricates. Reviewer gets blind/ only. Keep both keys sealed until d answers frozen. Producer scripts do not score/open reviewer responses; village stage only hashes their file bytes.

## Life captures

`P11_LIFE_OUT=<NEW_DIR> bash tools/art_pipeline/with_window_lock.sh 3600 <GODOT_BIN> --path <CHECKOUT> --fixed-fps 60 --resolution 1920x1080 --script res://scripts/test/art/capture_life_p11.gd`

Live seed20261010, d60–90 10:00: first living child/dead parent pair; first seen departed subject per cause0..4; EN/KO top and scroll captures with Life expanded. Chronicle panel catches up by advancing actual simulation one tick per page and logs exact tick. Reference JSON is separate from screenshots. UI contract is life_prep's show_person/_expand_life/_scroll and ChroniclePanel.toggle_visible/_next/_total. Need scheduled parser/runtime check; no Godot validation claimed.

## Verified during prep

- Python compileall succeeded.
- Exact archived v2 oracle unittest:17/17 PASS.
- Rectangle union checks:50% boundary,60% exclusion, duplicate overlap and nonoverlap PASS.
- No cargo, Godot, commits, or repository installs performed.
