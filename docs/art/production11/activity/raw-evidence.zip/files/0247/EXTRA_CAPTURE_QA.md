# Supplemental single capture wrapper

External prepared files: `tools/art_pipeline/run_extra_activity_p11.py`, `test_extra_activity_p11.py`.

Invocation (leader schedules; not run during prep):

```sh
P11_EXTRA_BASE_PLAN=/Users/rexxa/work/art-production11-evidence/activity-selection-base/exclusions-before-crops.json \
P11_ACTIVITY_BUILD_PROFILE=debug P11_DEADLINE_EPOCH=<epoch> \
python3 tools/art_pipeline/run_extra_activity_p11.py CHECKOUT NEWDIR 20261010 30 11 0
```

Only day30/live seed or day60/verified populous selection winner, hour11/14, zoom4, missing kind0..6. The requested kind/instant and reason/source SHA are written to preregistration.json before lock wait or launch. Actual wrapper and imported base-runner paths/hashes, source digest, bridge identity, HEAD/diff/status, selection and copied baseline plan are retained. Waits and launches reuse main audited runner helpers. Failed no-arrived launches retain logs and explicit no_arrived_holder flag; no synthetic screenshot or passing result is generated. All failures are preserved and next attempt must use a new directory. Pose result remains false until independent oracle checks.

Offline tests: `python3 .../test_extra_activity_p11.py`2/2 PASS (28 allowed combinations; disallowed seed/day/hour/kind cases); compileall PASS. No Godot/cargo/process launch.

Existing plain probe samples do not expose arrived-holder per-kind census. --agent-trace adds routine event/episode outputs which could reconstruct it, but is not a direct clock snapshot; no census shortcut or expensive new observer was added.
