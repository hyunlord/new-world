# Capture preparation static QA

Scope: external `capture-prep/` only; no cargo/Godot, no edits to main checkout, no reviewer answers opened.

## Concrete fixes

- Blind c now refuses repeated capture paths before creating output, requires the two day30 base frames to use the live seed, validates PNG dimensions, and requires additions to reuse a base seed/day with a valid centered activity kind.
- A given `(seed, AgentId, kind)` contributes at most one crop, so a repeated holder in a later capture cannot satisfy the second-holder quota. Selection remains capture-order first, AgentId ascending within capture; this explicit distinct-holder interpretation should be retained in the decision record.
- Blind d now rejects duplicate captures (preventing repeated village/capture pairs), incomplete Z1 sidecars, and zero/negative summary rectangles. It hashes source images/sidecars and verifies the c-answer file has not changed during preparation.

## Original crop and draw ordering

The archive's `prepare_blind_crops.py` remains byte-identical. P11 planner invokes its own protocol selection and the same crop/extraction formula; it does NOT invoke the old `main`, because that old selection accepts walking holders and sorts by override count. Offline regression compares every box/upscale/resampling against the actual archived `inventory` for25 sprite geometries. Original crop size and center are unchanged. No icon-fit adjustment was made; see BLIND_GEOMETRY_PREFLIGHT.md.

All agent/building body sprites are direct children of `WorldObjects`, which has `y_sort_enabled=true`. Capture order keys are `(sprite.z_index, sprite.global_position.y, sprite.get_index())`; only strictly higher order rectangles block a holder. Both body and blocker rects use `get_global_transform_with_canvas()*get_rect()`. Coverage is an exact rectangle-union area, so overlapping blockers count once and exactly50% remains eligible. This is rectangle coverage, not alpha-mask coverage. Scene hierarchy changes would require revisiting the ordering model.

## Commands and observed results

1. `python3 /Users/rexxa/work/art-production11-evidence/capture-prep/tools/art_pipeline/test_activity_protocol_p11.py`
   - Exit0;4 tests PASS: union coverage boundaries/overlap,25 original crop geometries, c duplicate capture rejection, d duplicate rejection.
2. `python3 -m compileall -q /Users/rexxa/work/art-production11-evidence/capture-prep/tools/art_pipeline`
   - Exit0.
3. `python3 /Users/rexxa/work/art-production11-evidence/capture-prep/tools/art_pipeline/p11_activity_oracle/test_activity_oracle.py`
   - Exit0;17 archived oracle tests PASS.

## Still requires scheduled real validation

Godot parser/import, actual sidecar metadata fields, y-sort visual ordering, release-backed captures, sidecar pose oracle on actual game_v24, and independent blind answers. No H7 pass claim follows from these offline checks. Additional captures remain explicitly preregistered/manual env launches; runner automates the base six only. Fresh reviewer receives only blind images/names, never producer code, this QA document, icon sheet or keys. Both keys stay sealed until d answers freeze.

## Explicit debug screenshot profile follow-up

External activity runner and driver support `P11_ACTIVITY_BUILD_PROFILE=debug` only when explicitly set; default remains `release`. Debug records the actual loaded debug-path SHA and independent release SHA (JSON null if release library is absent). Release continues to require matching release/loaded hashes. Missing loaded library and unsupported profile refuse capture. Driver emits the same build_identity per sidecar, including manually scheduled additional captures. Completed release-probe selection remains independent of screenshot build profile; debug screenshots are not release performance evidence.

`advance_ticks` review: activity driver resets to zero then calls advance once with absolute target amount, checking returned absolute tick against target; this was already correct. Final clock tick is also checked at capture frame130. The life driver's later incremental advances needed a different comparison; no main files were changed here.

Executed commands: `python3 tools/art_pipeline/test_activity_protocol_p11.py` from external mirror (5/5 PASS, including absent release/debug explicit, default release missing/mismatch rejection, matched release acceptance); `python3 -m compileall -q tools/art_pipeline` (PASS). No runtime or Godot/cargo launches.
