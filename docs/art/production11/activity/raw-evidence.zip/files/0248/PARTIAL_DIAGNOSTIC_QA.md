# Conditional partial diagnostic preparation — not installed or executed on actual evidence

Only external `tools/art_pipeline/plan_activity_blind_p11.py` changed; new `test_partial_activity_p11.py` validates authorization. Normal invocation still returns 1 with exclusions log and no crops when any kind has fewer than two eligible unique holders. No geometry, pose oracle, exclusion threshold, ordering, distinct-holder rule, or acceptance bar changed.

Optional invocation, ONLY after leader freezes terminal shortage:

```sh
python3 tools/art_pipeline/plan_activity_blind_p11.py --partial-diagnostic /ABS/terminal-shortage.json CHECKOUT NEWDIR BASE30_10 BASE30_15 BASE60_10 ADDITIONAL_JSON...
```

Terminal record schema: `schema:1`, `terminal_shortage:true`, `authorized_by:"leader"`, `remaining_capture_work:false`, nonempty `reason`, `required_count:14`, `capture_order` equal to the full ordered absolute input paths, `counts` equal to actual selected counts, and `source_hashes` mapping every input JSON and adjacent capture.png absolute path to SHA256. Leader must state whether terminality is allowed trials exhausted or deadline/resource exhaustion; never falsely label unattempted trials exhausted. Copy capture_order/counts/source_hashes from the final normal failed selection log, then add decision fields. Hashes are rechecked before any crop. An absent, stale, mismatched or incomplete record raises an error without crops. The exclusions log is written first even when authorization fails.

Diagnostic output uses precisely the actual eligible selection without excluded holders or duplicates/padding. protocol-status.json and key.json explicitly carry mode partial_diagnostic, actual_count, required_count14, full_protocol_complete:false, acceptance NOT_VERIFIED, original bar text and terminal record hash. Exit0 denotes artifact generation only. Blind choices/instructions remain unchanged; the observer must freeze answers before village task and must not see key/status. No actual blind keys or answers were inspected during preparation.

H7 recommendation: `c NOT_VERIFIED — required 14 eligible crops unavailable; diagnostic blind X/N only; ≥10/14 and no 0/2 criterion unachieved/unverified`. Report per-kind actual n separately; missing kinds are NOT_TESTED, never fabricated 0/2 or scaled to14. If observed errors already make passing impossible, retain diagnostic FAIL observations but do not imply the complete 14-crop protocol ran. Report d independently. Overall H7 cannot PASS while c is incomplete. N=0 cannot yield a blind observation; retain no-test evidence honestly.

Validation: `python3 -m py_compile .../plan_activity_blind_p11.py` exit0. `PYTHONPATH=<external tools>:<external tools>/p11_activity_oracle python3 -m unittest discover -s <external tools> -p 'test_*activity*p11.py'` passed10 tests (existing protocol6, extra runner2, terminal authorization2). No Godot/cargo/main edits or actual diagnostic crop generation performed.

## Agent108 occlusion audit

Actual source: `/Users/rexxa/work/art-production11-evidence/activity-extra-d60-1100-k0/capture.json`. Subject `/root/Main/WorldObjects/Agent_148`, rank635, rectangle[904,468,88,100]. All draw node paths and ranks unique. Own body occurs once, same rank, therefore excluded by strict greater-rank comparison. Seven intersecting foreground rectangles at ranks637,641,645,647,649,655,667 (other agents, two buildings, another agent's icon). Exact clipped union7856/8800=0.8927272727272727. No own-body duplication or overlapping-area double counting found. This validates rectangle-based coverage, not per-alpha pixel masking or UI-overlap coverage.
