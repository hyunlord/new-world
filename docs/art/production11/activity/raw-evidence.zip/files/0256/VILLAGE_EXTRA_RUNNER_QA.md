# Supplemental Z1 runner — external only, not executed

Prepared `tools/art_pipeline/run_village_extras_p11.py` and `test_village_extras_p11.py`.

After leader explicitly adopts the documented evidence extension and c answers have been frozen:

```sh
P11_ACTIVITY_BUILD_PROFILE=debug P11_DEADLINE_EPOCH=EPOCH python3 tools/art_pipeline/run_village_extras_p11.py CHECKOUT NEWDIR FROZEN_C_ANSWERS
```

Uses existing capture_activities_p11.gd unchanged. Before ANY capture registers all four cases in fixed order d30_11,d60_11,d30_14,d60_14 (live seed20261010, release-selected day60 winner), HEAD, source digest, actual bridge profile/hash, release hash if present, runner/driver/wrapper SHA, deadline, answers path/SHA. Answers are read as opaque bytes solely to require nonempty file and hash; no answer parsing/key access. Removes inherited P11_ACTIVITY_CENTER_KIND so original default overview -1 applies, zoom1. Existing quiet/window-lock and deadline helpers reused. Every case's failure/raw output retained; unsuccessful cases do not silently remove later scheduled cases. Deadline/source/answers changes prevent subsequent launches while recording failures. All four cases run regardless of favorable summary counts. No crops or scoring. Runner exit0 means all capture contracts passed, not six-pair acceptance. Original full six and >=5/6 criteria remain.

Offline validation: `python3 -m unittest discover -s <external tools> -p test_village_extras_p11.py` passed3 tests: exact case order and inherited-center removal; missing answers refuses before launch; mocked four failed launches prove full preregistration exists before first launch and all four failure records preserved. No Godot/cargo/main edits/captures.

`terminal-shortage-TEMPLATE.json` is intentionally NOT authorized: terminal_shortage:false, authorized_by:UNSET, remaining_capture_work:true, emptyreason. It includes all source hashes from selection-extra4 only as a template snapshot. Leader must regenerate capture_order/counts/source_hashes from FINAL normal selection, settle all cases, state true terminal reason, and explicitly authorize. Do not use this template as a terminal declaration. Partial planner will reject it. If captures continue, this template is stale and must be replaced, never patched to hide new inputs.
