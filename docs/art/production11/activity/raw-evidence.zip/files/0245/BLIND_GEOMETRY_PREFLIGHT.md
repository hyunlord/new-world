# Original crop geometry preflight, before any P11 blind crop

P10 v2 script geometry remains unchanged: square side `ceil(max(sprite_rect.width, sprite_rect.height)+16)`, centered on the body's drawn rectangle, followed by 4× nearest-neighbor presentation. For the usual taller-than-wide Z4 body this leaves only eight screen pixels above the body's top.

Static code review by activity_prep and life_prep found the existing overhead icon path places the icon's bottom at `sprite.offset.y - 2` world pixels, eight screen pixels above the body at Z4. Most or all of its silhouette can therefore lie outside the required crop. This is a pre-capture geometry concern, not a measured reviewer result. The final installed icon placement and actual sidecar geometry still need runtime inspection.

Neither prepare script expands, shifts, or substitutes crops to improve identification. Keep original geometry, log selection/exclusions before crops, and preserve any resulting low blind score. Any product placement revision must occur before the first capture and be recorded separately by the activity owner; never select crops based on reviewer answers.
