import json,os,subprocess,time
from pathlib import Path
root=Path('/Users/rexxa/work/new-world-art-prod');ev=Path('/Users/rexxa/work/art-production11-evidence')
paths=json.loads((ev/'activity-selection-extra4/exclusions-before-crops.json').read_text())['capture_order']
index=4
plan=ev/'activity-selection-extra4/exclusions-before-crops.json'
def add(folder):
 global index,plan
 p=ev/folder/'capture.json'
 if not p.exists():return
 result=json.loads((ev/folder/'launch.json').read_text())
 if not result['capture_contract_pass']:raise RuntimeError('invalid capture '+folder)
 paths.append(str(p));index+=1
 output=ev/f'activity-selection-extra{index}'
 code=subprocess.run(['python3','tools/art_pipeline/plan_activity_blind_p11.py',str(root),str(output),*paths],cwd=root).returncode
 if code not in (0,1):raise RuntimeError('planner error')
 plan=output/'exclusions-before-crops.json'
 print(folder,json.loads(plan.read_text())['counts'],flush=True)
while not (ev/'activity-extra-d60-1400-k2/launch.json').exists():time.sleep(5)
add('activity-extra-d60-1400-k2')
for seed,day,hour,kind in [(20261010,30,11,5),(20261010,30,11,2),(20261018,60,14,5)]:
 if kind not in json.loads(plan.read_text())['missing_kinds']:continue
 known=[]
 for p in paths:
  d=json.loads(Path(p).read_text())
  if (d['seed'],d['display_day'],d['hour'])==(seed,day,hour):known.append(d)
 if known and not any(x['kind']==kind and x['until_tick']>=0 for x in known[-1]['activity_holders']):
  print('NO_ARRIVED_FROM_GLOBAL_SNAPSHOT',seed,day,hour,kind,flush=True);continue
 folder=f'activity-extra-d{day}-{hour:02d}00-k{kind}'
 env=os.environ.copy();env.update(P11_ACTIVITY_BUILD_PROFILE='debug',P11_EXTRA_BASE_PLAN=str(plan),P11_DEADLINE_EPOCH='1792180200')
 code=subprocess.run(['python3','tools/art_pipeline/run_extra_activity_p11.py',str(root),str(ev/folder),str(seed),str(day),str(hour),str(kind)],cwd=root,env=env).returncode
 print('launch',folder,'exit',code,flush=True)
 if (ev/folder/'launch.json').exists():add(folder)
 else:raise RuntimeError('missing launch record '+folder)
(ev/'activity-extra-final-selection-path.txt').write_text(str(plan)+'\n')
print('FINISHED',plan,flush=True)
