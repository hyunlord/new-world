# Nonterminal capture inventory and bounded next checks

Read-only inventory; no terminal declaration, captures/crops generated, source edits, or runtime. Machine record TERMINAL_SHORTAGE_CHECKLIST.json uses selection-extra4: counts[0,2,0,2,1,1,2]. 104 exclusions remain preserved in the actual selection log.

Missing-kind combinations not yet resolved at inventory time:
- d30_11 kind4 queued/running; its valid full snapshot would also resolve whether kinds2/5 are present. d30_11 kind0 actual failed no-arrived attempt preserved.
- d30_11 kinds2/5 arrival UNKNOWN, not N/A; do not infer from another hour.
- d30_14 kind5 arrived IDs34,35, centering unattempted.
- d60_11 kind5 arrived IDs121,123,125, centering unattempted.
- d60_14 kind2 arrived IDs53,62,78,88,94,112; kind5 IDs124,125,126. Both centering unattempted. Root plans kind2 then kind5.

Provable no-arrived N/A from complete GLOBAL activity snapshots: d30_14 kinds0/2/4; d60_11 kinds2/4. d30_11 kind0 is proven by actual centering failure; no full snapshot exists from that failed attempt. Completed missing-kind center cases: d60_11k0, d60_14k0, d60_14k4. Other already-filled kinds need no targeted repetition. Recompute missing kinds after each valid capture and check exact pose/source provenance before adding selection inputs. A valid capture can incidentally reveal another kind; do not assume only center kind benefits.

TendFire geometric audit: d60_11 ID108 89.27%; d60_14 IDs59 57.41%,63 72.36%,67 34.47%,83 77.18%,116 68.94%. ID67 is offscreen and therefore excluded in k0-centered capture; another permitted centering may bring it into view. Therefore the claim 'all TendFire intrinsically over50%' is FALSE. Camera translation preserves rectangle union fractions at fixed zoom/order; rendering changes would require new evidence. Only one known allowed-time arrived TendFire is <=50%; no arrived ones exist d30_11/14. Current base selection has zero eligible kind0. This supports a ceiling of one unique eligible kind0 from currently authorized added instants, hence full two-kind0 bar cannot be met by those additions alone. Keep factual shortage separate from any decision to stop other diagnostic collection.

Before leader declares terminal: settle running captures; resolve unknown d30_11 inventory; document all attempted/remaining useful centering cases; classify skipped work accurately (exhausted versus deadline/resource bound); run final normal planner with ordered source list; preserve all exclusion logs and failed runs; freeze terminal record with final counts and hashes; only then consider diagnostic flag. Do not label an unattempted arrived target N/A.

## Z1 village audit and proposed extension, not executed

Three base Z1 inputs yield only THREE eligible pairs, never six:
- d30_10 seed20261010 village1: visible, inside, non-tied => one.
- d30_15 same village1: excluded top_two_tie (counts4/4); do not break tie by kind ordering.
- d60_10 seed20261018 villages1 and2: visible, inside, non-tied => two.

No crop or blind answer/key has been created or opened. Output here deliberately omits dominant answer kinds. At most two uses per(seed,village) allows one additional pair for each of those three actual villages. Base-only six-pair requirement is infeasible.

Helper already accepts an arbitrary ordered list of real distinct Z1 captures, so no selection logic change is required for an explicitly documented evidence extension. Suggested bounded preregistration: retain base order d30_10,d30_15,d60_10; append ALL four same-world supplemental instants in fixed hour-first order d30_11,d60_11,d30_14,d60_14. Use the standard Z1 overview camera for all, not kind-targeted favorable positioning. Produce actual same seed/day/tick captures, preserving provenance. Do not choose instants after seeing favorable summary counts, invent villages, duplicate frames, or count same village more than twice. Helper deterministically takes first six non-tied eligible pairs; even all four additions may remain insufficient. Capture-generation authorization/scheduling belongs to leader. Village crop preparation must still wait until c answers are frozen. Keep required six and >=5/6 unchanged; fewer pairs means NOT_VERIFIED, not a smaller passing denominator.
