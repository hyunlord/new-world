# Read-only omitted-center proof

Actual global sidecar rectangles recomputed using the same exact clipped rectangle-union algorithm as the production planner. Detail JSON: SKIPPED_CENTER_OCCLUSION_AUDIT.json.

| Omitted target | Arrived holder | Covered fraction |
|---|---:|---:|
| d30_14 Play |34|0.9730392156862745|
| d30_14 Play |35|0.5735294117647058|
| d60_11 Play |121|0.8946078431372549|
| d60_11 Play |123|0.5024509803921569|
| d60_11 Play |125|0.8088235294117647|

Every arrived holder of these target kinds is strictly >0.5 covered. Status must be SKIPPED_NO_ELIGIBLE_HOLDER_UNDER_RECTANGLE_RULE, never NO_ARRIVED. Agent123 is close to the threshold but remains above by0.0024509803921569; do not round to50% or apply tolerance. Offscreen rectangles are retained in global collection; their inclusion is essential to this conclusion.

For a common camera translation t, intersection(R+t,B+t)=intersection(R,B)+t; union area and subject area are unchanged, hence coverage ratio is unchanged. Assumptions: same simulation seed/tick, zoom4, same fixed capture animation phase, identical geometry/visibility and draw ranks, all world Sprite2D rectangles retained (no viewport clipping before area calculation), and common camera translation without camera-dependent declumping/LOD/geometry changes. This is a mathematical rectangle-rule inference conditional on those assumptions, not an actual screenshot from the omitted camera. UI overlap and alpha-pixel masking remain outside this rule. Any runtime violation of equal geometry/order would require fresh evidence, not continued reliance on this proof. The existing lowest-AgentId centering cannot improve a target's ratio under these assumptions. Other missing-kind camera captures may still make eligible offscreen holders visible, but cannot reduce their intrinsic rectangle coverage.

Base TendFire inspection: d30_10 and d30_15 have no arrived TendFire; d60_10 IDs97/107/109 are all offscreen with coverage1.0/0.6677018633540373/0.7788235294117647. No eligible offscreen base TendFire was found. The fixed base camera rule remains unchanged; this audit does not authorize reframing it. No source/runtime changes or crops.
