#!/usr/bin/env python3
# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
# How to run: python3 package_perf.py NEW_ARCHIVE.zip FILE [FILE ...]
"""Package explicit terminal artifacts with SHA256 round-trip verification.

No directory traversal, globs, inferred companion files, or prior-file overwrite.
Paths and original names are retained in manifest.json. Hashing is streamed.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path


def digest(path: Path) -> str:
    """Hash a file without loading large frame archives into memory."""
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def package(target: Path, inputs: list[Path]) -> None:
    """Create an immutable archive and verify every payload before success."""
    if not inputs:
        raise ValueError('Explicit input files required')
    target = target.absolute()
    seen: set[Path] = set()
    sources = []
    for argument in inputs:
        if argument.is_symlink():
            raise ValueError(f'Symlink input forbidden: {argument}')
        source = argument.resolve(strict=True)
        if not source.is_file() or source in seen or source == target:
            raise ValueError(f'Non-file, duplicate or self input: {argument}')
        seen.add(source)
        sources.append(source)
    rows = [{'source': str(source), 'member': f'files/{index:04d}/{source.name}',
             'size': source.stat().st_size, 'sha256': digest(source)}
            for index, source in enumerate(sources)]
    manifest = {'schema_version': 1, 'created_utc': datetime.now(timezone.utc).isoformat(),
                'archive': str(target), 'inputs_explicit_only': True, 'files': rows}
    raw_manifest = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    manifest_sha = hashlib.sha256(raw_manifest).hexdigest()
    # Reserve the result before writing: no replacement even on failure.
    with target.open('xb') as reserved:
        with zipfile.ZipFile(reserved, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
            archive.writestr('manifest.json', raw_manifest)
            archive.writestr('manifest.sha256', manifest_sha + '  manifest.json\n')
            for source, row in zip(sources, rows):
                archive.write(source, str(row['member']))
                if source.stat().st_size != row['size'] or digest(source) != row['sha256']:
                    raise RuntimeError(f'Input changed while packaging; retained rejected archive: {source}')
        reserved.flush()
        os.fsync(reserved.fileno())
    with zipfile.ZipFile(target) as archive:
        if hashlib.sha256(archive.read('manifest.json')).hexdigest() != manifest_sha:
            raise RuntimeError('Manifest round-trip mismatch; archive retained')
        if len(archive.namelist()) != len(rows) + 2:
            raise RuntimeError('Unexpected archive entries; archive retained')
        for row in rows:
            with archive.open(str(row['member'])) as stream:
                actual = hashlib.file_digest(stream, 'sha256').hexdigest()
            if actual != row['sha256']:
                raise RuntimeError(f'Payload round-trip mismatch; archive retained: {row["member"]}')
    print(json.dumps({'archive': str(target), 'sha256': digest(target), 'manifest_sha256': manifest_sha,
                      'files': len(rows), 'bytes': target.stat().st_size, 'roundtrip_verified': True}))


if __name__ == '__main__':
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    package(Path(sys.argv[1]), [Path(value) for value in sys.argv[2:]])
