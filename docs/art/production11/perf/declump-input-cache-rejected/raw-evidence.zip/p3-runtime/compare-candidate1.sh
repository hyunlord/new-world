#!/usr/bin/env bash
set -uo pipefail
cd /Users/rexxa/work/new-world-art-prod
base=/Users/rexxa/work/art-production11-evidence/p3-runtime
out="$base/candidate1-comparison"
mkdir "$out" || exit 2
python3 tools/art_pipeline/verify_draw_clock_p11.py "$base/six-attempt2/A" "$base/six-attempt2/Aprime" "$base/candidate1/B" > "$out/draw-clock.log" 2>&1
printf '%s\n' "$?" > "$out/draw-clock.exit"
python3 tools/art_pipeline/pixel_identity_p11.py "$base/six-attempt2/A" "$base/six-attempt2/Aprime" "$base/candidate1/B" "$out/pixels" > "$out/pixels.log" 2>&1
printf '%s\n' "$?" > "$out/pixels.exit"
python3 tools/art_pipeline/compare_running_identity_p11.py "$base/running-A" "$base/candidate1/running-B" "$out/running.json" > "$out/running.log" 2>&1
printf '%s\n' "$?" > "$out/running.exit"
cat "$out/draw-clock.exit" "$out/pixels.exit" "$out/running.exit"
