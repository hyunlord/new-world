#!/usr/bin/env bash
set -euo pipefail
root=/Users/rexxa/work/new-world-art-prod
evidence=/Users/rexxa/work/art-production11-evidence
output=$1
mkdir "$output"
export P11_P3_PLAN="$evidence/p3-runtime/p3-plan.json"
export P11_P3_TARGET_TICK=46189
bash "$evidence/p3-prep/run_running_identity_p11.sh" --snapshot "$root" > "$output/source.before.json"
set +e
bash "$root/tools/art_pipeline/run_identity_p11.sh" "$root" "$output" B > "$output/six-driver.log" 2>&1
rc=$?
set -e
printf '%s\n' "$rc" > "$output/six-driver.exit"
bash "$evidence/p3-prep/run_running_identity_p11.sh" --snapshot "$root" > "$output/source.after.json"
cmp "$output/source.before.json" "$output/source.after.json"
[[ $rc -eq 0 ]] || exit "$rc"
bash "$evidence/p3-prep/run_running_identity_p11.sh" "$root" "$output/running-B"
