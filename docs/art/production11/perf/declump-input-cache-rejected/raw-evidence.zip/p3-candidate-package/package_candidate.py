"""Archive terminal P11 candidate evidence without modifying original artifacts."""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import shutil
from typing import Final
from zipfile import ZIP_DEFLATED, ZipFile

BASE: Final = Path('/Users/rexxa/work/art-production11-evidence')
OUT: Final = BASE / 'p3-candidate-package'
DOCS: Final = Path('/Users/rexxa/work/new-world-art-prod/docs/art/production11/perf/declump-input-cache-rejected')
COMMIT: Final = '1dc641b5cd161cf9683349f367194935e8213b3f'
ROOTS: Final = (
    'p3-candidate-tests', 'p3-runtime/candidate1-build', 'p3-runtime/candidate1',
    'p3-runtime/candidate1-comparison', 'p3-pair-declump-input-cache',
    'p3-runtime/base-instrumentation', 'p3-candidate-package/rejected-source',
)
SINGLES: Final = (
    'p3-pair-declump-input-cache-driver.log', 'p3-runtime/run-candidate-identity.sh',
    'p3-runtime/compare-candidate1.sh', 'p3-runtime/p3-plan.json',
    'p3-runtime/reference-archive.json', 'p3-runtime/reference-validation.json',
    'p3-runtime/reference-validation.md', 'p3-runtime/reference-filelist.json',
    'p3-prep/declump-input-plan.md', 'p3-candidate-package/holds-terminal-snapshot.md',
    'p3-candidate-package/candidate-commit.patch', 'p3-candidate-package/package_candidate.py',
)


def main() -> None:
    """Check terminal evidence, archive immutable bytes, verify every ZIP member."""
    pair = json.loads((BASE / 'p3-pair-declump-input-cache/summary.json').read_text())
    launch = json.loads((BASE / 'p3-pair-declump-input-cache/launch.json').read_text())
    pixels = json.loads((BASE / 'p3-runtime/candidate1-comparison/pixels/comparison.json').read_text())
    running = json.loads((BASE / 'p3-runtime/candidate1-comparison/running.json').read_text())
    assert launch['exit_code'] == 0 and launch['finished']
    assert launch['before'] == launch['after']
    assert launch['before']['head'] == COMMIT
    assert launch['before']['build_sha256'] == launch['before']['release_sha256']
    assert pair['valid'] and pair['median_speedup'] < 1
    assert pixels['passed'] and len(pixels['framings']) == 6
    assert all(row['candidate']['pixels'] == 0 and row['control']['pixels'] == 0 for row in pixels['framings'])
    assert running['valid'] and running['status'] == 'PASS' and len(running['worlds']) == 4
    checks = json.loads((BASE / 'p3-candidate-tests/attempt2/results.json').read_text())
    assert len(checks) == 7 and all(row['exit'] == 0 and not row['errors'] for row in checks)
    exit_paths = [path for directory in ROOTS[1:4] for path in (BASE / directory).rglob('*.exit')]
    exit_paths.append(BASE / 'p3-pair-declump-input-cache/session.exit')
    assert len(exit_paths) == 11 and all(path.read_text().strip() == '0' for path in exit_paths)
    reference = json.loads((BASE / 'p3-runtime/reference-archive.json').read_text())
    reference_path = BASE / 'p3-runtime/reference-raw-evidence.zip'
    assert sha256(reference_path.read_bytes()).hexdigest() == reference['sha256']
    with ZipFile(reference_path) as archive:
        assert archive.testzip() is None
    selected = {BASE / name for name in SINGLES}
    for directory in ROOTS:
        selected.update(path for path in (BASE / directory).rglob('*') if path.is_file())
    snapshots: dict[str, bytes] = {}
    for path in sorted(selected):
        assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(BASE)
        snapshots[str(path.relative_to(BASE))] = path.read_bytes()
    entries = [{'path': name, 'bytes': len(data), 'sha256': sha256(data).hexdigest()} for name, data in snapshots.items()]
    manifest = {
        'status': 'COMPLETE_TERMINAL_EVIDENCE', 'candidate_commit': COMMIT,
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'identity_H5_candidate': 'PASS', 'performance': 'REJECTED', 'adopted': False,
        'median_speedup': pair['median_speedup'], 'control': pair['control'], 'candidate': pair['candidate'],
        'pair_pixel_identity_field': 'NOT_VERIFIED: standalone pair validator does not ingest identity results; independent complete comparison is PASS',
        'retained_failures': ['red.log missing API', 'first test fixture SCRIPT ERROR despite exit0; attempt2 corrected fixture passed'],
        'provenance_before_equals_after': True, 'release_debug_sha256_equal': True,
        'terminal_exit_records': {str(path.relative_to(BASE)): 0 for path in exit_paths},
        'reference_archive': {'path': str(reference_path), 'sha256': reference['sha256'], 'crc_rechecked': True, 'separate_archive': True},
        'files': entries,
    }
    manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
    sums = ''.join(f"{entry['sha256']}  {entry['path']}\n" for entry in entries).encode()
    payload = snapshots | {'manifest.json': manifest_bytes, 'SHA256SUMS': sums}
    archive_path = OUT / 'raw-evidence-v2.zip'
    with ZipFile(archive_path, 'x', compression=ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in payload.items():
            archive.writestr(name, data)
    with ZipFile(archive_path) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist()))
        assert set(archive.namelist()) == set(payload)
        assert archive.testzip() is None
        for name, data in payload.items():
            restored = archive.read(name)
            assert len(restored) == len(data) and sha256(restored).digest() == sha256(data).digest()
    assert all((BASE / name).read_bytes() == data for name, data in snapshots.items())
    (OUT / 'manifest.json').write_bytes(manifest_bytes)
    (OUT / 'SHA256SUMS').write_bytes(sums)
    validation = {'archive': str(archive_path), 'sha256': sha256(archive_path.read_bytes()).hexdigest(),
        'bytes': archive_path.stat().st_size, 'source_files': len(snapshots), 'zip_members': len(payload),
        'zip_crc_verified': True, 'all_member_sha256_roundtrip_verified': True, 'source_stability_verified': True}
    (OUT / 'archive-validation.json').write_text(json.dumps(validation, indent=2) + '\n')
    DOCS.mkdir(parents=True, exist_ok=True)
    for name in ['raw-evidence-v2.zip', 'manifest.json', 'SHA256SUMS', 'archive-validation.json']:
        target = DOCS / ('raw-evidence.zip' if name == 'raw-evidence-v2.zip' else name)
        shutil.copyfile(OUT / name, target)
        assert (OUT / name).read_bytes() == target.read_bytes()
    print(json.dumps(validation, indent=2))


if __name__ == '__main__':
    main()
