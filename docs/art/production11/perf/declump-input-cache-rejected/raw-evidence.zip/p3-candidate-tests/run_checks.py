from pathlib import Path
import subprocess,time,json,sys
root=Path('/Users/rexxa/work/new-world-art-prod');out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
godot='/Users/rexxa/Downloads/Godot.app/Contents/MacOS/Godot'
checks=[('strict',['bash','tools/harness/gdscript_strict_check.sh','scripts/ui/camp_seats.gd','scripts/ui/agent_renderer.gd','scripts/test/art/test_declump_cache_p11.gd'])]
checks += [(n,[godot,'--headless','--path',str(root),'--script','res://scripts/test/art/'+n+'.gd']) for n in ['test_declump_cache_p11','test_declump','test_spatial_hash_p10','test_camp_seat_cache_p10','test_camp_seats','test_activity_installed_p10']]
rows=[]
for name,cmd in checks:
 assert not Path('/Users/rexxa/work/.mac_quiet.lock').exists()
 start=time.time()
 with (out/(name+'.log')).open('w') as log:
  r=subprocess.run(['bash','tools/art_pipeline/run_bounded.sh','120',*cmd],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 text=(out/(name+'.log')).read_text();bad='SCRIPT ERROR' in text or 'ERROR:' in text
 row={'name':name,'exit':r.returncode,'errors':bad,'seconds':time.time()-start};rows.append(row);print(json.dumps(row),flush=True)
 (out/(name+'.exit')).write_text(str(r.returncode)+'\n')
 if r.returncode or bad:break
(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(int(any(r['exit'] or r['errors'] for r in rows)))
