#!/usr/bin/env bash
set -euo pipefail
main=/Users/rexxa/work/new-world-art-prod
base=/Users/rexxa/work/art-p11-base
evidence=/Users/rexxa/work/art-production11-evidence
while [[ ! -f "$main/docs/art/production11/perf/baseline.json" ]]; do sleep 15; done
while [[ -d /Users/rexxa/work/.mac_quiet.lock ]]; do sleep 15; done
export P11_P3_PLAN="$evidence/p3-runtime/p3-plan.json"
export P11_P3_TARGET_TICK=46189
bash "$main/tools/art_pipeline/run_identity_p11.sh" "$base" "$evidence/p3-runtime/six-attempt2" Aprime
bash "$evidence/p3-prep/run_running_identity_p11.sh" "$base" "$evidence/p3-runtime/running-A"
