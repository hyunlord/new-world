"""Synthetic comparator contract tests; these are not game identity evidence."""
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import json
import shutil
from compare_running_identity_p11 import compare, WORLDS


def fixtures(root: Path) -> None:
    """Produce structurally complete fixtures with an empty first pan frame."""
    for label, tick, seed in WORLDS:
        pan = label.startswith('W500')
        frozen = label == 'W500_FROZEN'
        count = 240 if pan else 600
        every = 0 if frozen else (1 if pan else 2)
        ticks = [tick + (0 if frozen else i // every + 1) for i in range(count)]
        start = [-200, 500] if pan else [1000, 500]
        rows = []
        for i in range(count):
            sprite = {'id': 1, 'position': [1, 2], 'texture': 'atlas.png', 'region': [0, 0, 16, 16],
                      'region_enabled': True, 'flip_h': False, 'visible': True, 'visible_in_tree': True,
                      'modulate': [1, 1, 1, 1], 'self_modulate': [1, 1, 1, 1], 'z_index': 1,
                      'z_as_relative': True, 'children': []}
            rows.append({'frame': i+1, 'process_frame': 241+i, 'tick': ticks[i], 'population': 500,
                         'camera': [start[0]+(10*i if pan else 0), start[1]],
                         'agents': [] if pan and i == 0 else [sprite]})
        dump = ''.join(json.dumps(row, sort_keys=True)+'\n' for row in rows).encode()
        (root/f'{label}.jsonl').write_bytes(dump)
        counts = {'pre_draw': 1, 'post_draw': 1, 'engine_frames_drawn': 1}
        meta = {'world': label, 'seed': seed, 'start_tick': tick, 'end_tick': ticks[-1], 'frames': count,
                'fixed_fps': 60, 'advance_every_frames': every, 'mutation_route': 'SimReads',
                'advance_calls': ticks[-1]-tick, 'render_start_frame': 120, 'warmup_frames': 120,
                'process_frames': list(range(241, 241+count)), 'ticks': ticks, 'scope': 'viewport_plus_64px',
                'pan': pan, 'pan_step_world_px': 10 if pan else 0, 'speed': 0 if frozen else (2 if pan else 1),
                'populations': [500]*count, 'camera_start': start, 'hearth': [1000, 500],
                'camera': rows[-1]['camera'], 'zoom': 4, 'debug_build': True, 'build_commit': 'fixture',
                'build_sha256': 'fixture', 'collector_sha256': 'fixture', 'world_info': {'scene': 'synthetic'},
                'validated_delta_samples': count, 'render_counts_start': counts, 'render_counts_end': counts,
                'render_counts': [counts]*count, 'dump_sha256': hashlib.sha256(dump).hexdigest()}
        (root/f'{label}.json').write_text(json.dumps(meta))


def run() -> None:
    """Check exact pass and fail-closed incomplete/mutated captures."""
    with TemporaryDirectory() as temp:
        base = Path(temp)/'base'; candidate = Path(temp)/'candidate'
        base.mkdir(); fixtures(base); shutil.copytree(base, candidate)
        assert compare(base, candidate)['valid'], compare(base, candidate)
        path = candidate/'W500_2X.jsonl'
        original = path.read_bytes()
        path.write_bytes(original.replace(b'"flip_h": false', b'"flip_h": true', 1))
        assert not compare(base, candidate)['valid']
        path.write_bytes(original)
        path = candidate/'W500_FROZEN.json'
        meta = json.loads(path.read_text()); meta['render_counts'] = []; path.write_text(json.dumps(meta))
        assert not compare(base, candidate)['valid']
        shutil.rmtree(candidate); shutil.copytree(base, candidate)
        (candidate/'W200.jsonl').unlink()
        assert not compare(base, candidate)['valid']
        print('PASS: complete exact pair; changed sprite rejects; missing render evidence rejects; missing world rejects')


if __name__ == '__main__':
    run()
