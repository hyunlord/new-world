# Static review and existing evidence reuse (2026-10-16 UTC)

No Godot, cargo, simulation or benchmarks executed. All writes remain in external p3-prep. This review does not claim parse/runtime success. Existing evidence SHA256s are recorded in `framing-existing-evidence-sha256.json`.

## Reuse actual observations before searching

| Framing | Inherited seed/tick | Current actual evidence | Decision |
|---|---|---|---|
| P1/P6 | 20261010/40560 | `perf/baseline-W0-attempt1.json`, build b94bfef736f24f6f9e0567c39bb5d7ce5950916f: initial tick40560,pop29,alive_settlements1,camera808,356,Z4 | Prerequisites already proved. Reuse seed/tick; no tick search. Six-framing capture records actual fire/snapshot census for final reference. |
| P2 | 20261010/31320 | No exact current tick/fire census found. Current P2 activity captures tick41880/42180 are daytime and do not prove night31320 | One exact P2 census first; search only if it fails lit-night criterion. |
| P3 | 20261013/46189 | Current release game_v24 probe at46080:36alive/1living village;46200:37alive/2living villages. No exact46189 row. Historical P10 census46189 has37people and2villages [22,15] | One exact P3 census; threshold2 occupied villages matches original framing semantics. Do not impose3 or use historical count as current proof. |
| P4 | 20261013/126994 | Completed `perf/baseline-W1-attempt1.json`, P0 build b94bfef736f24f6f9e0567c39bb5d7ce5950916f: tick126994,pop66,alive_settlements2,camera808,676,errors=[] | Reuse original seed/tick/Z1 overview. Two living villages meet the inherited multi-village purpose. No P4 census/search needed. Historical3 was observation, not acceptance bar. |
| P5 | 15100/1440/stress500 | `perf/baseline-W500-attempt1.json`, same P0 build: tick1440,pop500,alive_settlements1,camera1016,500 | Reuse exact seed/tick; no search. Repeatable pixels still require draw-clock A/A′ proof. |

P2 actual day60 seed20261018 tick85080 captures show92people and2inhabited villages [42,50]. This proves an alternative multi-village state exists; it is not proof for inherited P3/P4 and does not establish first tick. Prefer the exact inherited probes before replacing seeds. Probe binary provenance is `activity-probe-head.txt` = ecf512d886d87ba7f9ca5fa7db92a48300dc1c68; P2 captures record loaded debug bridge SHA aa6da070ff17861f8dc21d8f6203643dec3d8c44a8d94b90525c388eb89cdd8a. Different build identity remains explicit.

The performance world/tick workloads stay immutable. Re-derived identity cases do not change perf W1 or any P0 baseline workload.

## Static harness review and corrections

- Rechecked `advance_ticks` absolute-tick return: running harness now checks `start_tick + advance_calls + 1`, not literal1.
- `DrawClock` field explicitly uses the preloaded script type, avoiding an untyped member. All newly introduced GDScript state, args and returns carry types; no added integer/integer division.
- Confirmed Godot4.6 official `RenderingServer.xml` declares `force_draw(bool swap_buffers=true,float frame_step=0)` and frame_pre_draw/frame_post_draw signals. The chosen explicit positive step API is valid by source inspection; runtime signal ordering remains unverified.
- P3 render control is now gated by `CAPTURE_IDENTITY_P11=1`; nonidentity uses retain original force_draw behavior. Its deferred final draw runs after scene processing without adding another process frame, preserving120settled frames.
- Native world `_process` remains disabled in deterministic running checks; 2× pan uses one SimReads tick per60FPS frame (30TPS×2), accurately labeled manual schedule. Camera processing disabled, camera scroll forced after each pan step.
- Transform-filter includes the current drawn sprite rect against viewport grown64px, preserves invisible sprites in the band and all original comparison properties. No crop mask or changed pixel threshold.
- Helper observes unexpected auto/resource render callbacks despite `--disable-render-loop`, and fails closed instead of silently accepting uncontrolled renderer time.
- Limitation: P3's very large historical capture file remains inherited; no promise that all pre-existing strict warnings are absent. Godot parse/import and real control captures are still required.

## Minimal sequential orchestration

`run_p3_prepared.sh` stages files, builds/imports each checkout sequentially, runs one exact census, or launches one six-framing label. It validates the base HEAD equals supplied frozen Part2SHA, preserves distinct output dirs, waits out quiet holds and uses the window-lock/bounded wrappers. It does not create worktrees/branches, alter .gdextension, select an optimization or touch perf workload constants.

After the leader creates the authorized base worktree at Part2final, set `BASE`, `CANDIDATE`, `P2_SHA`, `EVIDENCE` to those real paths/hash:

```sh
script=/Users/rexxa/work/art-production11-evidence/p3-prep/run_p3_prepared.sh
bash "$script" setup "$BASE" "$CANDIDATE" "$P2_SHA" "$EVIDENCE"
bash "$script" census "$BASE" "$CANDIDATE" "$P2_SHA" "$EVIDENCE" P2
bash "$script" census "$BASE" "$CANDIDATE" "$P2_SHA" "$EVIDENCE" P3
# P4 is already supported by completed W1 evidence; do not search.
```

Read exact census results; retain inherited cases if their prerequisites pass. If replacements are necessary, follow the bounded search instructions in SIX_FRAMINGS.md with min-villages2 forP3; P4 needs no search. Finalize identical case scripts and derived P3 plan/tick. Then:

```sh
export P11_P3_PLAN=/absolute/verified/p3-plan.json
export P11_P3_TARGET_TICK=VERIFIED_TICK
bash "$script" identity "$BASE" "$CANDIDATE" "$P2_SHA" "$EVIDENCE" A
bash "$script" identity "$BASE" "$CANDIDATE" "$P2_SHA" "$EVIDENCE" Aprime
# Inspect A/A′ control before candidate. Do not retry a failing target beyond GOAL's limit.
bash "$script" identity "$BASE" "$CANDIDATE" "$P2_SHA" "$EVIDENCE" B
python3 /Users/rexxa/work/art-production11-evidence/p3-prep/verify_draw_clock_p11.py "$EVIDENCE/six/A" "$EVIDENCE/six/Aprime" "$EVIDENCE/six/B"
python3 tools/art_pipeline/pixel_identity_p11.py "$EVIDENCE/six/A" "$EVIDENCE/six/Aprime" "$EVIDENCE/six/B" "$EVIDENCE/six/comparison"
```

These placeholders explicitly require the leader's frozen Part2 identity. Do not run setup while Part2 capture source is frozen. A completed setup does not replace commit/gate/bridge provenance verification and actual A/A′ acceptance.

Offline verification: shell `bash -n` for orchestration and identity runner; Python compile and prior comparator synthetic contracts. No performance claim is made.

## P4 clarification (same-date update)

The earlier min3 preparation assumption is withdrawn, not silently relaxed as a user bar. `docs/art/production9/GOAL.md:113` defines P4 as W1 Z1 at126994 with overview layers on, without a settlement-count threshold. `docs/art/production10/GOAL.md:67` says P3/P4 should show several villages. `docs/art/production10/baseline/README.md:9` explicitly accepts two as the established multi-village purpose for P3; line24 records P4's historical3, an observation rather than a numeric acceptance rule. The leader accepted preserving P4's original seed/tick/Z1 based on the now measured two living villages. This keeps framing and workload fixed and avoids an unnecessary search. Only P2/P3 exact census remain required before identity captures. No unused checkpoint utility was added or installed.
