from pathlib import Path
import hashlib
import json
import sys
from datetime import datetime, timezone
from PIL import Image
sys.path.insert(0, '/Users/rexxa/work/new-world-art-prod/tools/art_pipeline')
from verify_draw_clock_p11 import validate
from compare_running_identity_p11 import compare_world, WORLDS
from pixel_identity_p11 import difference
root = Path(__file__).parent
six = root / 'six-attempt2'
running = root / 'running-A'
report = {'scope': 'REFERENCE_ONLY_NOT_H5_CANDIDATE', 'recorded_utc': datetime.now(timezone.utc).isoformat(), 'errors': [], 'six': [], 'running_A': [], 'candidate_identity': 'NOT_MEASURED'}
for framing in ('P1','P2','P3','P4','P5','P6'):
    stamps = [json.loads((six / label / f'{framing}.json').read_text()) for label in ('A','Aprime')]
    errors = []
    try:
        clocks_equal = validate(stamps[0]) == validate(stamps[1])
        if not clocks_equal: errors.append('Complete observed clock sequences differ')
    except (ValueError, KeyError, TypeError) as exc:
        clocks_equal = False
        errors.append(str(exc))
    with Image.open(six/'A'/f'{framing}.png') as a, Image.open(six/'Aprime'/f'{framing}.png') as b:
        metric, _ = difference(a.convert('RGBA'), b.convert('RGBA'))
    if metric.pixels or metric.max_channel: errors.append('RGBA difference is nonzero')
    for key in ('capture_frame','state_change_frame','tick','seed','fixed_fps'):
        if stamps[0].get(key) != stamps[1].get(key): errors.append(f'Stamp mismatch: {key}')
    clock = stamps[0]['draw_clock']
    report['six'].append({'framing': framing, 'valid': not errors, 'errors': errors, 'clock_sequences_exact': clocks_equal, 'rgba_pixels': metric.pixels, 'rgba_maximum': metric.max_channel, 'manual_steps':clock['manual_steps'], 'automatic_steps':clock['automatic_steps'], 'pre_draws':clock['pre_draws'], 'files': {str(six/label/f'{framing}.{suffix}'):hashlib.sha256((six/label/f'{framing}.{suffix}').read_bytes()).hexdigest() for label in ('A','Aprime') for suffix in ('json','png')}})
for spec in WORLDS:
    label = spec[0]
    # Self-input invokes all existing structural checks; equality to self is NOT evidence of candidate identity.
    checked = compare_world(running, running, spec)
    errors = list(checked['errors'])
    meta = json.loads((running/f'{label}.json').read_text())
    provenance = [json.loads((running/'provenance'/f'{label}.{phase}.json').read_text()) for phase in ('before','inside','after')]
    if not provenance[0] == provenance[1] == provenance[2]: errors.append('Launch provenance changed')
    if meta['build_commit'] != provenance[0]['head'] or meta['build_sha256'] != provenance[0]['debug_sha256']: errors.append('Capture build differs from launch provenance')
    collector = 'scripts/test/art/capture_running_identity_p11.gd'
    if provenance[0]['sources'].get(collector) != meta['collector_sha256']: errors.append('Collector hash differs from launch source manifest')
    counts = meta['render_counts']
    # Each dumped frame records monotonically advancing actual draw counts.
    previous = meta['render_counts_start']
    for index, count in enumerate(counts):
        if any(count[k] < previous[k] for k in ('pre_draw','post_draw','engine_frames_drawn')): errors.append(f'Render counters decrease at row {index+1}')
        previous = count
    if previous != meta['render_counts_end']: errors.append('Final draw counts differ')
    report['running_A'].append({'world':label,'valid':not errors,'errors':errors,'frames':meta['frames'],'start_tick':meta['start_tick'],'end_tick':meta['end_tick'],'population_start':meta['populations'][0],'population_end':meta['populations'][-1],'build_commit':meta['build_commit'],'build_sha256':meta['build_sha256'],'source_sha256':provenance[0]['source_sha256'],'dump_sha256':meta['dump_sha256'],'structure_validation':'existing comparator on self-input; no candidate comparison','render_counts_start':meta['render_counts_start'],'render_counts_end':meta['render_counts_end']})
for directory, expected in [(six/'A',6),(six/'Aprime',6),(running,4)]:
    rows = (directory/'launches.tsv').read_text().splitlines()[1:]
    if len(rows) != expected: report['errors'].append(f'{directory}: launch row count mismatch')
    for row in rows:
        cells=row.split('\t')
        if cells[3:6] != ['0','present','none'] or (directory == running and cells[6] != 'unchanged'): report['errors'].append(f'{directory}: invalid launch {row}')
    for log in (directory/'logs').glob('*.log'):
        if 'ERROR' in log.read_text(): report['errors'].append(f'ERROR in {log}')
report['valid'] = not report['errors'] and all(row['valid'] for row in report['six'] + report['running_A'])
(root/'reference-validation.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['# Reference-only validation', '', f"Status: {'PASS' if report['valid'] else 'FAIL'}. Candidate identity / H5: **NOT_MEASURED**.", '', 'Offline validation of actual A/A′ clocks and RGBA, plus running-A structure and recorded provenance. No runtime or source changes.', '', '| Framing | Clock exact | RGBA pixels / max | Manual / automatic draws | Result |','|---|---|---|---|---|']
for row in report['six']: lines.append(f"| {row['framing']} | {row['clock_sequences_exact']} | {row['rgba_pixels']} / {row['rgba_maximum']} | {row['manual_steps']} / {row['automatic_steps']} | {'PASS' if row['valid'] else 'FAIL'} |")
lines += ['', '| Running reference | Frames | Tick start → end | Population start → end | Structure/provenance |','|---|---|---|---|---|']
for row in report['running_A']: lines.append(f"| {row['world']} | {row['frames']} | {row['start_tick']} → {row['end_tick']} | {row['population_start']} → {row['population_end']} | {'PASS' if row['valid'] else 'FAIL'} |")
lines += ['', 'Running validation uses the existing comparator with the same reference as both inputs solely to execute its frame/property/schedule/checksum checks. Equality to itself is not candidate identity. Before/inside/after source and debug hashes were separately checked, as were collector/build hashes, terminal launch rows and monotonic render counts. Per-framing A/A′ complete observed clocks were independently validated and compared exactly; RGBA has no mask or tolerance.', '', 'The six-framing supplemental base-provenance record was captured during A, not a per-launch before/after audit. Preserve that provenance limitation; running-A has full per-launch snapshots. All results and file hashes are in reference-validation.json.']
errors=report['errors']+[e for row in report['six']+report['running_A'] for e in row['errors']]
if errors: lines += ['', 'Errors:'] + ['- '+e for e in errors]
(root/'reference-validation.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'valid':report['valid'],'errors':errors,'six':[{k:v for k,v in r.items() if k!='files'} for r in report['six']],'running':report['running_A']},indent=2))
