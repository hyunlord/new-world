# Six-framing identity staging (NOT runtime verified)

Prepared outside the repository. No scenes, sprites, water textures, masks, pixel comparator or pixel acceptance bounds are changed. Existing P11 pixel comparator remains byte-for-byte unchanged. Manual positive renderer steps are capture instrumentation only, installed identically into both worktrees.

## Files and install boundary

At Part 3 only, after Part 2 final reference SHA is fixed, install external copies into main and base paths:

- `identity_draw_clock_p11.gd` → `scripts/test/art/identity_draw_clock_p11.gd`
- `capture_identity_p11.gd` → `scripts/test/art/capture_identity_p11.gd`
- `capture_framings_p11.gd` → `scripts/test/capture_framings_p11.gd`
- `probe_baseline_p11.gd` → `scripts/test/art/probe_baseline_p11.gd`
- `run_identity_p11.sh` → `tools/art_pipeline/run_identity_p11.sh`

Base copies are untracked instrumentation only. Preserve base commit and bridge hashes. Build bridge then import every checkout as GOAL1.1 requires before any launch. No changes to the historical P10 sources/evidence.

## Live re-derivation commands

Run each command from the selected base checkout, after ensuring the quiet lock is absent; wrap all Godot launches in the window lock as below. The scene-less probe is still Godot and must obey the no-Godot-during-foreign-hold rule. Use a fresh result filename per invocation. All output data is unmeasured until these commands actually run.

```sh
checkout=/Users/rexxa/work/art-p11-base
staging=/Users/rexxa/work/art-production11-evidence/p3-prep
for name in identity_draw_clock_p11.gd capture_identity_p11.gd probe_baseline_p11.gd; do cp "$staging/$name" "$checkout/scripts/test/art/$name"; done
cp "$staging/capture_framings_p11.gd" "$checkout/scripts/test/capture_framings_p11.gd"
cp "$staging/run_identity_p11.sh" "$checkout/tools/art_pipeline/run_identity_p11.sh"
cd "$checkout"
mkdir -p /Users/rexxa/work/art-production11-evidence/p3-derive
```

The bridge build/import prerequisites must be executed under the parent's allowed runtime schedule, not by this preparation. Then for each original framing P1 through P6:

```sh
case_id=P1
out=/Users/rexxa/work/art-production11-evidence/p3-derive/$case_id.json
env P11_BASELINE_OUT="$out" bash tools/art_pipeline/with_window_lock.sh 1800 \
  bash -c 'while [[ -d /Users/rexxa/work/.mac_quiet.lock ]]; do sleep 30; done; exec "$@"' census \
  /Users/rexxa/Downloads/Godot.app/Contents/MacOS/Godot --path "$checkout" \
  --script res://scripts/test/art/probe_baseline_p11.gd -- --mode=framings --case="$case_id"
```

Record actual world_info, tick, population, living settlement count (`member_counts >0`), fire_lit rows and lit_night. P1/P6 require a living village/person; P2 requires night and the framed first village's lit hearth, not merely another lit village. P3/P4 require several occupied villages. P5 remains stress seed15100 tick1440 population500; report actual survivors, not requested count.

Only if an exact required P2/P3 census is invalid, use exact first-tick search (`stride=1,start-tick=0`) first on the current framing seed, then seeds20261011 through20261042 in order. The probe now counts inhabited villages rather than archived settlement rows. Example first lit-night search; for P3 use `--purpose=villages --min-villages=2`; P4 now has exact W1 evidence and requires no search; for empty P1/P6 use `--purpose=occupied` and separately retain a readable daylight time if the found tick is night (document that choice):

```sh
out=/Users/rexxa/work/art-production11-evidence/p3-derive/night-search-seed20261010.json
env P11_BASELINE_OUT="$out" bash tools/art_pipeline/with_window_lock.sh 3600 \
  bash -c 'while [[ -d /Users/rexxa/work/.mac_quiet.lock ]]; do sleep 30; done; exec "$@"' census \
  /Users/rexxa/Downloads/Godot.app/Contents/MacOS/Godot --path "$checkout" \
  --script res://scripts/test/art/probe_baseline_p11.gd -- --mode=search --purpose=night \
  --seed=20261010 --last-seed=20261010 --start-tick=0 --max-tick=172800 --stride=1
```

A timeout is incomplete search, not absent framing. Keep incomplete JSON/logs; three-strike rule still applies. Sequential per-seed launches avoid one unbounded33seed run. The existing probe writes partial output at seed boundaries, not every tick; avoid claiming full searched range if it timed out.

Update CASES in `capture_identity_p11.gd` and FRAMINGS in `probe_baseline_p11.gd` to observed seed/tick values in the installed and staged copies; P1/P6 should share one verified case. Re-derive identity framings only. Preserve the immutable Part 0 performance baseline workloads, including W1 seed and tick; after measurements must use those same worlds and ticks. Copy identical finalized scripts to all involved checkouts. No values are supplied here because no runtime was allowed.

P3 uses the inherited all-villages FV camera algorithm. Its hardcoded tick46189 check is replaced with required `P11_P3_TARGET_TICK`, and runner requires a derived plan file. Convert the verified tick using clock_offset from that same world's census:

```sh
python3 - <<'PY'
import json
from pathlib import Path
row=json.loads(Path('/Users/rexxa/work/art-production11-evidence/p3-derive/P3.json').read_text())['rows'][0]
info=row['world_info']; tick=int(row['clock']['tick']); offset=int(info['clock_offset_ticks'])
day,minute=divmod(tick+offset,1440)
hour,minute=divmod(minute,60)
seed=int(info['seed'])
folder=Path('/Users/rexxa/work/art-production11-evidence/p3-derive')
(folder/'p3-plan.json').write_text(json.dumps([["RESET",seed],[day+1,f'{hour:02d}:{minute:02d}','FV','all']])+"\n")
(folder/'p3-tick.txt').write_text(str(tick)+"\n")
print('derived P3 seed/tick:',seed,tick)
PY
```

Write plan `[ ["RESET", verified_seed], [derived_day,"HH:MM","FV","all"] ]` to a permanent derivation artifact before starting A. Set `P11_P3_PLAN` to that path and `P11_P3_TARGET_TICK` to the verified tick. This removes the duplicated runner literal while preserving P3's actual FV setup.

## Renderer clock controls and A/A′/B protocol

Run `run_identity_p11.sh` independently for A and Aprime on base, B on candidate:

```sh
env P11_P3_PLAN=/Users/rexxa/work/art-production11-evidence/p3-derive/p3-plan.json \
  P11_P3_TARGET_TICK="$(cat /Users/rexxa/work/art-production11-evidence/p3-derive/p3-tick.txt)" \
  bash tools/art_pipeline/run_identity_p11.sh "$checkout" \
  /Users/rexxa/work/art-production11-evidence/p3-six A
```

The plan and tick files above are generated only from live census. Repeat with Aprime then candidate checkout/B. Each output directory is created exclusively, preventing reuse/overwriting. Read logs, exit codes, sidecars before comparing pixels.

Runner adds `--disable-render-loop`. `identity_draw_clock_p11.gd` advances rendering with explicit `force_draw(false,1/60)` once for each observed process frame; duplicate requests at capture do not advance a second time. Both capture scripts replace their final zero-step force draw with that idempotent request. Water uses the same atlas, frames and3FPS animation and continues advancing. The helper records origin/last frame, manual step count, pre/post callbacks and Engine.frames_drawn. It fails capture if process frames skip or any extra render callbacks are observed, catching pending-resource draws that Godot may still perform despite disabled automatic presentation.

Before the unchanged pixel comparator, require all six sidecars' draw_clock.valid=true and exact A/Aprime/B equality of origin_frame,last_frame,manual_steps,step_seconds,pre_draws,post_draws,automatic_loop_disabled. A complete rendering-clock validation must reject missing fields. Engine.frames_drawn is additional diagnostic provenance (manual force draws may not increment it).

Then run the original pixel tool with its original bounds:

```sh
evidence=/Users/rexxa/work/art-production11-evidence/p3-six
python3 /Users/rexxa/work/art-production11-evidence/p3-prep/verify_draw_clock_p11.py "$evidence/A" "$evidence/Aprime" "$evidence/B" && \
python3 tools/art_pipeline/pixel_identity_p11.py "$evidence/A" "$evidence/Aprime" "$evidence/B" "$evidence/comparison"
```

No claim of repeatable P5 can be made until repeated A/A′ PNG hashes and draw-clock records agree at runtime. Startup graphics-resource behavior may still trigger unexpected draw callbacks; that is a fail-closed diagnostic, not permission to mask water or relax bounds. If A/A′ water remains different despite validated equal explicit steps, preserve evidence and report the unresolved cause rather than accepting the cache.

## Offline verification

`bash -n run_identity_p11.sh` passes. GDScript parse, rendering callbacks, asynchronous command completion, live framing selection, A/A′ water identity and all six pixel acceptance checks remain NOT_VERIFIED because no Godot/cargo/runtime was authorized for this preparation.


P4 update, 2026-10-16: current W1 initial proves seed20261013/tick126994/pop66/two living villages. Preserve original P4 seed/tick/Z1; no search. The earlier min3 suggestion was a preparation assumption, withdrawn after source review: production9/GOAL.md:113 has no count bar, production10/GOAL.md:67 requires several villages, and production10/baseline/README.md:24 merely reports historical3 (line9 accepts2 as established multi-village purpose). See STATIC_REVIEW_AND_REUSE.md for exact decision provenance.
