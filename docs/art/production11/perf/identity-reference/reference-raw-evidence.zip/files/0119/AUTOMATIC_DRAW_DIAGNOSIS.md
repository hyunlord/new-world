# Automatic draw observations, 2026-10-16 UTC

Read-only diagnosis of `p3-runtime/six-attempt2/A`; no clock change or runtime launch performed. Sources inspected while A captures were active; A/A′ repeatability is not yet established by these observations.

| Framing | State / capture process frame | Manual | Automatic | Automatic process frames |
|---|---|---:|---:|---|
| P1 | 10 / 130 | 131 | 35 | 10 through 44 |
| P2 | 10 / 130 | 131 | 1 | 10 |
| P3 | 1 / 121 | 122 | 120 | 0, 1, 3 through 120 |

These are different framings, not repeat captures of the same framing. Their differing counts do not by themselves establish nondeterminism. P3 uses its inherited state setup at frame1 and120 settled frames; the other collector starts state setup at10. Each must match its own A′/B event sequence, not another framing's sequence.

Official Godot 4.6 `Main::iteration` performs draw when either the window wants presentation or RD has pending resources, even when the automatic render-loop property is disabled. `RenderingDevice::_free_internal` sets `frames_pending_resources_for_processing` to the frame-buffer count; `_free_pending_resources` decrements it. Resource retirement can therefore replenish pending draws. The exact project resource responsible for the35/120 observed draws has not been identified: it is not justified to label this shader compilation or CPU-load nondeterminism from counts alone.

Sources: [Main draw dispatch](https://github.com/godotengine/godot/blob/4.6/main/main.cpp), [RenderingDevice resource retirement](https://github.com/godotengine/godot/blob/4.6/servers/rendering/rendering_device.cpp), [pending-resource counter predicate](https://github.com/godotengine/godot/blob/4.6/servers/rendering/rendering_device.h).

If repeated same-framing captures fail clock equality, a bounded possible remedy is enabling the normal render loop in the identity harness while preserving the manual schedule, then requiring exactly one automatic draw for every completed process frame, plus all scheduled manual draws. For a capture inside process frameN before Main's draw, expected automatic frames are0..N−1. With a drawable window, pending resources no longer decide whether the Main draw occurs. This remains an untested proposal; observed event completeness, actual deltas, time scales, and A/A′/B exact sequence equality must still be verified. Do not change the active capture source or relax pixel criteria. A pure prewarm plus counter reset is insufficient because it discards already accumulated compositor time.

P5 exactness is a separate acceptance rule. The inherited generic comparator accepts a nonzero control difference if the candidate is bounded by it. GOAL4.3 requires P5 to reproduce exactly, so P5 must require both A/A′ and A/B differing-pixel counts to be zero. The new bounded comparator regression uses a one-pixel alpha-only change; both prior false-accept cases were reproduced before the fix. Other framings retain the original two-metric bounds. Compare A2/P5 against existing `p3-clock-diagnostic2` when both artifacts are complete before deciding on any clock change.
