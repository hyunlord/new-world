#!/usr/bin/env bash
cd /Users/rexxa/work/new-world-art-prod || exit 2
P11_BUILD_PROFILE=release P11_DEADLINE_EPOCH=1792180200 P11_WORLDS="W0 W500 W200 W1" bash tools/art_pipeline/run_perf_matrix_p11.sh after /Users/rexxa/work/art-p11-measure /Users/rexxa/work/art-production11-evidence/perf-after > /Users/rexxa/work/art-production11-evidence/p4-matrix-resume-driver.log 2>&1
printf '%s\n' "$?" > /Users/rexxa/work/art-production11-evidence/p4-matrix-driver.exit
P11_BUILD_PROFILE=release P11_DEADLINE_EPOCH=1792180200 python3 tools/art_pipeline/run_agent_sections_p11.py /Users/rexxa/work/art-p11-measure /Users/rexxa/work/art-production11-evidence/p4-sections-W500-attempt1 > /Users/rexxa/work/art-production11-evidence/p4-sections-driver.log 2>&1
printf '%s\n' "$?" > /Users/rexxa/work/art-production11-evidence/p4-sections-driver.exit
