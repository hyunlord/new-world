# Deadline test transcript (synthetic; no measurement rows)

Command run on the same five-test source, before and after the two-file correction:

`python3 -m unittest discover -s tools/art_pipeline -p test_deadline_p11.py`

RED: exit1, 5 tests in6.994s, two failures:

- test_admitted_child_can_finish_past_admission_cutoff: AssertionError143 !=0; Terminated15.
- test_section_outer_wait_allows_one_hold_and_cleanup: AssertionError2 !=3612.

GREEN: exit0:

```text
.....
----------------------------------------------------------------------
Ran 5 tests in 9.603s

OK
```

Other three cases: expired admission never launches; foreign lock survives wait deadline; hold cap still terminates child. All fixtures use temporary lock/tree, fake load/process probes, harmless sleeps; no real Mac lock or Godot.

Additional commands all exited0 after patch:

```sh
bash -n tools/art_pipeline/with_quiet_lock_p11.sh
python3 -m py_compile tools/art_pipeline/run_agent_sections_p11.py tools/art_pipeline/test_deadline_p11.py
git diff --check
```

This records actual prior tool outputs, not a new run. Test artifact is tools/art_pipeline/test_deadline_p11.py. No synthetic data was placed in measured summaries.
