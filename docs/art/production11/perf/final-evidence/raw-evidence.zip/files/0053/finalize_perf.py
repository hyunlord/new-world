#!/usr/bin/env python3
# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
# How to run: python3 finalize_perf.py CONFIG.json NEW_OUTPUT_DIRECTORY
"""Finalize explicit terminal P11 evidence offline; never launch measurements."""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

import report_perf as report

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'p0-report-prep'))
from package_perf import digest, package


def text_field(config: report.Record, key: str) -> str:
    """Require an explicit configuration string, including '-' for missing timers."""
    value = config.get(key)
    if not isinstance(value, str) or not value:
        raise RuntimeError('Required nonempty string: ' + key)
    return value


def copy_new(source: Path, target: Path) -> None:
    """Preserve exact bytes without replacing existing evidence."""
    with source.open('rb') as incoming, target.open('xb') as outgoing:
        shutil.copyfileobj(incoming, outgoing)
    if digest(source) != digest(target):
        raise RuntimeError('Copy SHA mismatch: ' + str(source))


def finalize(config_path: Path, output: Path) -> None:
    """Validate full aggregates, render raw tables, and archive explicit provenance."""
    config = report.read(config_path)
    repo = Path(text_field(config, 'repo')).resolve(strict=True)
    sys.path.insert(0, str(repo / 'tools/art_pipeline'))
    baseline = Path(text_field(config, 'baseline')).resolve(strict=True)
    after = Path(text_field(config, 'after')).resolve(strict=True)
    before, before_notes = report.verified_input(str(baseline), 'baseline', 'summarize_perf_p11')
    later, after_notes = report.verified_input(str(after), 'after', 'summarize_perf_p11')
    required = {'W0', 'W1', 'W200', 'W500'}
    if set(before) != required or set(later) != required:
        raise RuntimeError('Finalization requires exactly W0/W1/W200/W500 valid sessions per phase')
    for label, sessions in [('baseline', before), ('candidate', later)]:
        expected = text_field(config, label + '_sha')
        for world, raw in sessions.items():
            if report.obj(raw).get('build_commit') != expected:
                raise RuntimeError(f'{label}/{world}: unexpected build commit')
    section_before = text_field(config, 'sections_before')
    section_after = text_field(config, 'sections_after')
    section_lines = report.sections(section_before, section_after)
    section_files: list[Path] = []
    for name, expected in [(section_before, text_field(config, 'baseline_sha')), (section_after, text_field(config, 'candidate_sha'))]:
        if name == '-':
            continue
        summary_path = Path(name).resolve(strict=True)
        raw_path = summary_path.with_name('frames.json')
        if report.read(raw_path).get('build_commit') != expected:
            raise RuntimeError('Section build commit mismatch: ' + name)
        section_files.extend([summary_path, raw_path])
    explicit = [Path(str(item)).resolve(strict=True) for item in report.arr(config.get('extra_files'))]
    if any(not path.is_file() for path in explicit):
        raise RuntimeError('extra_files must explicitly name regular files')
    # All input parsing precedes creation; a failed attempt never overwrites prior output.
    output.mkdir(parents=False, exist_ok=False)
    preserved_before, preserved_after = output / 'baseline-aggregate.json', output / 'after-aggregate.json'
    copy_new(baseline, preserved_before)
    copy_new(after, preserved_after)
    copy_new(config_path, output / 'config.json')
    notes = before_notes + after_notes
    historical = report.historical(text_field(config, 'art10_baseline'), text_field(config, 'art10_after'))
    generated: list[Path] = []
    for compact, filename in [(False, 'performance-full.md'), (True, 'performance-compact.md')]:
        path = output / filename
        lines = report.render(before, later, notes, compact=compact) + section_lines + historical
        with path.open('x') as stream:
            stream.write('\n'.join(lines) + '\n')
        generated.append(path)
    raw_files = [Path(str(path)).resolve(strict=True) for aggregate in (baseline, after) for path in report.arr(report.read(aggregate)['sources'])]
    inputs = [preserved_before, preserved_after, output / 'config.json', *raw_files, *section_files, *explicit, *generated,
              Path(__file__).resolve(), Path(report.__file__).resolve()]
    # One file can serve multiple provenance roles; retain its unique source once.
    inputs = list(dict.fromkeys(inputs))
    archive = output / 'raw-evidence.zip'
    package(archive, inputs)
    index = {'schema_version': 1, 'archive': str(archive), 'archive_sha256': digest(archive),
             'archive_bytes': archive.stat().st_size, 'within_40mb': archive.stat().st_size < 40_000_000,
             'baseline_sha': config['baseline_sha'], 'candidate_sha': config['candidate_sha'],
             'aggregate_sha256': {'baseline': digest(preserved_before), 'after': digest(preserved_after)},
             'reports': [str(path) for path in generated], 'sections_before': section_before,
             'sections_after': section_after, 'roundtrip_verified': True,
             'files': [{'path': str(path), 'sha256': digest(path)} for path in inputs]}
    with (output / 'index.json').open('x') as stream:
        json.dump(index, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'output': str(output), 'bytes': index['archive_bytes'],
                      'sha256': index['archive_sha256'], 'within_40mb': index['within_40mb']}))


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    finalize(Path(sys.argv[1]).resolve(strict=True), Path(sys.argv[2]).absolute())
