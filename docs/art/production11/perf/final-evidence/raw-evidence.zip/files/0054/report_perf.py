#!/usr/bin/env python3
# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
# How to run: python3 report_perf.py REPO BASELINE_JSON AFTER_JSON OUTPUT_MD [ART10_BASELINE_JSON ART10_AFTER_JSON]
"""Render validated raw performance evidence; '-' means explicitly absent.

Imports only standard-library repository evidence validators. Does not launch
Godot, touch source files, synthesize samples, or decide H5/H7/H8.
"""
from __future__ import annotations

import hashlib
import importlib
import json
import math
import statistics
import sys
from pathlib import Path
from typing import TypeAlias

Json: TypeAlias = None | bool | int | float | str | list['Json'] | dict[str, 'Json']
Record: TypeAlias = dict[str, Json]


def obj(value: Json) -> Record:
    """Require a JSON object at the evidence boundary."""
    if not isinstance(value, dict):
        raise RuntimeError(f'Expected object, got {type(value).__name__}')
    return value


def arr(value: Json) -> list[Json]:
    """Require a JSON array at the evidence boundary."""
    if not isinstance(value, list):
        raise RuntimeError(f'Expected array, got {type(value).__name__}')
    return value


def read(path: Path) -> Record:
    """Read evidence without treating malformed files as absence."""
    return obj(json.loads(path.read_text()))


def display(value: Json) -> str:
    """Missing measurements are text, never zero."""
    if value is None:
        return 'NOT_MEASURED'
    if isinstance(value, float):
        return f'{value:.4f}'
    return str(value).replace('|', '\\|').replace('\n', ' ')


def verified_input(name: str, phase: str, module_name: str) -> tuple[Record, list[str]]:
    """Require an aggregate's raw sources to match its embedded session rows."""
    if name == '-':
        return {}, [f'{phase}: NOT_MEASURED (explicitly absent)']
    source = Path(name).resolve()
    data = read(source)
    module = importlib.import_module(module_name)
    if data.get('phase') != phase:
        raise RuntimeError(f'{source}: phase mismatch')
    sources, rows = arr(data.get('sources')), arr(data.get('sessions'))
    if len(sources) != len(rows):
        raise RuntimeError(f'{source}: raw source/session count mismatch')
    sessions: Record = {}
    notes = [f'{phase} aggregate `{source}` sha256 `{hashlib.sha256(source.read_bytes()).hexdigest()}`']
    for raw_path, embedded in zip(sources, rows):
        path = Path(str(raw_path))
        if not path.is_absolute():
            path = Path.cwd() / path
        raw = read(path)
        if raw != obj(embedded):
            raise RuntimeError(f'{path}: raw file differs from aggregate')
        session = module.load_session(path)
        if session.phase != phase or session.world in sessions:
            raise RuntimeError(f'{path}: mixed phase or duplicate world')
        if raw.get('valid') is not True or raw.get('errors') != []:
            notes.append(f'REJECTED `{path}`: invalid session/errors; not used in metrics')
            continue
        expected = 'release' if module_name.endswith('p11') else 'debug'
        if raw.get('build_profile') != expected:
            raise RuntimeError(f'{path}: requires {expected} profile')
        sessions[session.world] = raw
        notes.append(f'{session.world}: `{path}`, HEAD `{raw.get("build_commit")}`, bridge SHA `{raw.get("build_sha256")}`, contended `{raw.get("contended")}`')
    return sessions, notes


def table(lines: list[str], headers: list[str], rows: list[list[Json]]) -> None:
    """Append an ordinary Markdown table."""
    lines.extend(['', '| ' + ' | '.join(headers) + ' |', '|' + '|'.join('---' for _ in headers) + '|'])
    lines.extend('| ' + ' | '.join(display(value) for value in row) + ' |' for row in rows)
    lines.append('')


def render(before: Record, after: Record, notes: list[str], compact: bool = False) -> list[str]:
    """Compute from samples via the checked-in P11 validator/comparator."""
    compare = importlib.import_module('compare_perf_p11')
    result = obj(compare.compare(before, after, compare.Evidence({}, {}, {}, {})))
    verdicts = obj(result['verdicts'])
    lines = ['# Art Pass 11 성능 측정', '',
             'release bridge. 주 지표 = process_ms + render_cpu_ms; 백분위 = nearest-rank. 배수 = 전/후 중앙값. 미측정값은 0으로 채우지 않는다.', '',
             'H5/H7/H8은 이 성능 집계기의 판정 범위 밖이다. 표의 running 전체 수치는 표시된 블록도 포함하며 H4만 제외한다.']
    rows: list[list[Json]] = []
    for key in ('H1', 'H2', 'H3', 'H4'):
        row = obj(verdicts[key]); a, b = obj(row['before']), obj(row['after'])
        rows.append([key, row['status'], a['median'], b['median'], b['p99'], row['median_speedup'], row.get('reason', '')])
    h6 = obj(verdicts['H6'])
    rows.append(['H6', h6['status'], json.dumps(h6['before']), json.dumps(h6['after']), None, None, 'AgentRenderer ablation; no bar'])
    table(lines, ['항목', '판정', '전 중앙값 ms', '후 중앙값 ms', '후 p99 ms', '배수', '근거/제한'], rows)
    lines.append('## 세계·화면·조건별 원시 샘플 재집계')
    rows = []
    for label, value in obj(result['conditions']).items():
        row = obj(value)
        if compact and (label.startswith('W1000/') or label.endswith('/tick-only')):
            continue
        for side in ('before', 'after'):
            for metric, values in obj(row[side]).items():
                if compact and metric != 'primary_cpu_ms':
                    continue
                stat = obj(values)
                rows.append([label, side, metric, stat['count'], stat['median'], stat['p90'], stat['p99'], stat['maximum']])
    if compact:
        paired = []
        for index in range(0, len(rows), 2):
            a, b = rows[index:index + 2]
            paired.append([a[0], ' / '.join(display(value) for value in a[4:]), ' / '.join(display(value) for value in b[4:])])
        table(lines, ['조건', '전 중앙값/p90/p99/최대 ms', '후 중앙값/p90/p99/최대 ms'], paired)
    else:
        table(lines, ['조건', '시점', '지표', '프레임', '중앙값', 'p90', 'p99', '최대'], rows)
    lines.append('## 블록별 인구와 ticks/frame')
    rows = []
    for side, sessions in (('before', before), ('after', after)):
        for world, value in sessions.items():
            for raw_block in arr(obj(value)['blocks']):
                block = obj(raw_block)
                if block.get('condition') not in ('frozen', 'running'):
                    continue
                samples = arr(block['samples']); context = obj(compare.running_context(samples))
                rows.append([side, world, block['label'], block.get('population_start'), block.get('population_end'), block.get('population_flagged'), block.get('fresh_setup'), context.get('ticks_per_frame'), context.get('tick_carrying_frames')])
    table(lines, ['시점', '세계', '블록', '시작 인구', '끝 인구', '표시', '새 설정', 'ticks/frame', 'tick 프레임'], rows)
    h4 = obj(verdicts['H4'])
    lines.append('H4 비표시 블록 수: `' + json.dumps(h4['unflagged_blocks']) + '`. 후 측정 비표시 블록이 2개 미만이면 NOT_VERIFIED.')
    lines.append('## 노드별 ablation')
    rows = []
    for world, value in obj(result['ablation']).items():
        sides = obj(value)
        a = {str(obj(row)['node']): obj(row)['cost_ms'] for row in arr(sides['before'])}
        b = {str(obj(row)['node']): obj(row)['cost_ms'] for row in arr(sides['after'])}
        for node in sorted(a.keys() | b.keys()):
            rows.append([world, node, a.get(node), b.get(node)])
    table(lines, ['세계', '노드/그룹', '전 ms', '후 ms'], rows)
    lines.extend(['## 출처', '', *('- ' + note for note in notes)])
    return lines


def historical(base: str, after: str) -> list[str]:
    """Keep Art Pass 10 debug verdicts strictly separate."""
    a, an = verified_input(base, 'baseline', 'summarize_perf_p10')
    b, bn = verified_input(after, 'after', 'summarize_perf_p10')
    compare = importlib.import_module('compare_perf_p10')
    result = obj(compare.compare(a, b, compare.Evidence({}, {}, {}, {})))
    lines = ['', '## Art Pass 10 사후 판정 (debug, 별도)', '']
    rows: list[list[Json]] = []
    for key in ('H1', 'H3', 'H6'):
        row = obj(obj(result['verdicts'])[key])
        rows.append([key, row['status'], json.dumps(row.get('before')), json.dumps(row.get('after'))])
    table(lines, ['항목', '판정', '전', '후'], rows)
    lines.extend('- ' + note for note in an + bn)
    return lines


def sections(before: str, after: str) -> list[str]:
    """Compare validated section samples; absence is never a zero timer."""
    collected: dict[str, Record] = {}
    for side, name in (('before', before), ('after', after)):
        collected[side] = {}
        if name == '-':
            continue
        path = Path(name)
        data = read(path)
        raw = read(path.with_name('frames.json'))
        if data.get('valid') is not True or data.get('errors') != [] or data.get('exit_code') != 0 or raw.get('valid') is not True or raw.get('errors') != []:
            raise RuntimeError('Invalid section evidence: ' + name)
        if raw.get('build_profile') != 'release' or raw.get('build_sha256') != raw.get('release_sha256'):
            raise RuntimeError('Invalid section release provenance: ' + name)
        samples = arr(raw.get('samples'))
        if len(samples) != 300:
            raise RuntimeError('Section evidence requires 300 counted frames')
        for key, expected in obj(data.get('section_statistics_usec')).items():
            values = sorted(obj(obj(row)['agent_sections'])['total_usec'] if key == 'total_usec' else obj(obj(obj(row)['agent_sections'])['exclusive_usec'])[key] for row in samples)
            actual = {'median': statistics.median(values), 'p90': values[math.ceil(len(values) * .9) - 1], 'p99': values[math.ceil(len(values) * .99) - 1], 'max': values[-1]}
            if actual != obj(expected):
                raise RuntimeError('Section summary/raw mismatch: ' + key)
            collected[side][key] = actual
    lines = ['', '## 구간 타이머 (μs; 계측 진단)', '']
    rows: list[list[Json]] = []
    for key in sorted(collected['before'].keys() | collected['after'].keys()):
        cells = []
        for side in ('before', 'after'):
            row = obj(collected[side].get(key, {}))
            cells.append(' / '.join(display(row.get(field)) for field in ('median', 'p90', 'p99', 'max')))
        rows.append([key, *cells])
    table(lines, ['구간', '전 중앙값/p90/p99/최대', '후 중앙값/p90/p99/최대'], rows)
    if not rows:
        lines.append('NOT_MEASURED: 구간 타이머 입력 없음.')
    return lines


def main() -> int:
    """Read explicitly selected attempts and write one new report."""
    section_paths = {'--sections-before': '-', '--sections-after': '-'}
    for option in section_paths:
        if option in sys.argv:
            index = sys.argv.index(option)
            section_paths[option] = sys.argv[index + 1]
            del sys.argv[index:index + 2]
    compact = '--compact' in sys.argv
    if compact:
        sys.argv.remove('--compact')
    if len(sys.argv) not in (5, 7):
        raise SystemExit(__doc__)
    repo, base, after, output = sys.argv[1:5]
    sys.path.insert(0, str(Path(repo).resolve() / 'tools/art_pipeline'))
    a, an = verified_input(base, 'baseline', 'summarize_perf_p11')
    b, bn = verified_input(after, 'after', 'summarize_perf_p11')
    lines = render(a, b, an + bn, compact=compact)
    lines.extend(sections(section_paths['--sections-before'], section_paths['--sections-after']))
    lines.extend(historical(*sys.argv[5:7]) if len(sys.argv) == 7 else historical('-', '-'))
    with Path(output).open('x') as stream:
        stream.write('\n'.join(lines) + '\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
