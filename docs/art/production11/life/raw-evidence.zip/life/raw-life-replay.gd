extends SceneTree
const ReadRoute = preload("res://scripts/test/art/test_sim_reads_equivalence_p9.gd")
func _init() -> void:
	call_deferred("_run")
func _run() -> void:
	var output: String = OS.get_environment("P11_RAW_LIFE_OUT")
	if output.is_empty() or FileAccess.file_exists(output):
		push_error("P11_RAW_LIFE_OUT must be a new file")
		quit(1)
		return
	var scene: PackedScene = load("res://scenes/main.tscn") as PackedScene
	var main: Node = scene.instantiate()
	var world: Node = main.get_node("WorldSim")
	world.call("set_sim_speed", 0.0)
	world.process_mode = Node.PROCESS_MODE_DISABLED
	root.add_child(main)
	current_scene = main
	await process_frame
	ReadRoute.mutate(world, "reset_world", [20261010])
	var advanced: int = int(ReadRoute.mutate(world, "advance_ticks", [85080]))
	if advanced != 85080:
		push_error("replay advance mismatch")
		quit(1)
		return
	await process_frame
	var snapshots: Dictionary = {}
	for getter: String in ["get_agent_snapshot", "get_settlement_snapshot", "get_construction_snapshot", "get_building_snapshot", "get_resource_snapshot", "get_time_snapshot", "get_tallies", "get_society_snapshot", "get_intervention_state", "get_world_info", "get_activity_snapshot"]:
		snapshots[getter] = ReadRoute.read(world, getter)
	var agents: Dictionary = snapshots["get_agent_snapshot"]
	var persons: Dictionary = {}
	for agent_id: int in [0, 1, 25, 36, 39, 40, 50]:
		var item: Dictionary = {"person": world.call("get_person", agent_id), "chronicle": world.call("get_person_chronicle", agent_id)}
		var index: int = agents["agent_ids"].find(agent_id)
		if index >= 0:
			var entity: int = int(agents["ids"][index])
			item["entity_bits"] = entity
			item["detail"] = world.call("get_agent_detail", entity)
			item["family"] = world.call("get_agent_family", entity)
		persons[str(agent_id)] = item
	var result: Dictionary = {"seed": 20261010, "tick": 85080, "method": "independent deterministic replay; separate from original screenshot run", "bridge_sha256": FileAccess.get_sha256("res://rust/target/debug/libsim_bridge.dylib"), "snapshots": snapshots, "persons": persons}
	var file: FileAccess = FileAccess.open(output, FileAccess.WRITE)
	if file == null:
		quit(1)
		return
	file.store_string(JSON.stringify(result, "\t"))
	file.close()
	quit(0)
