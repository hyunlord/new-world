import json, hashlib, re
from pathlib import Path
root=Path('/Users/rexxa/work/new-world-art-prod'); base=Path('/Users/rexxa/work/art-production11-evidence'); capture=base/'life-attempt2'; raw=json.loads((capture/'reference-data.json').read_text()); review=json.loads((base/'life-review-round1.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def mix(x):
 x=(x^0x9E3779B9)&0xffffffff
 for _ in range(2): x=((x^(x>>16))*0x45D9F3B)&0xffffffff
 return x^(x>>16)
src=(root/'scripts/ui/person_names.gd').read_text(); en=json.loads(re.search(r'const EN: Array\[String\] = (\[.*\])',src)[1]);ko=json.loads(re.search(r'const KO: Array\[String\] = (\[.*\])',src)[1])
def names(i):
 h=mix(mix(i)^0x2545F491); ix=[(h>>(5*j+2))%46 for j in range(2 if h%4==0 else 3)];tries=0
 while any(s in ''.join(en[j] for j in ix) for s in ['nig','kak','baka']) or any(s in ''.join(ko[j] for j in ix) for s in ['시바','바보','미치','시비']):
  ix[-1]=(ix[-1]+1)%46;tries+=1
  if tries%46==0:
   for j in range(len(ix)-2,-1,-1):
    ix[j]=(ix[j]+1)%46
    if ix[j]:break
 return [''.join(en[j] for j in ix).capitalize(),''.join(ko[j] for j in ix)]
def event(path,idx):
 obj=raw
 for key in path.split('/')[1:]: obj=obj[int(key)] if isinstance(obj,list) else obj[key]
 return {'file':'reference-data.json','json_pointer':path,'parallel_array_index':idx,'fields':{k:obj[k][idx] for k in ['tick','kind','subject','other','third','settlement','cause','value']},'derived_day':(obj['tick'][idx]+480)//1440+1}
L='/captures/living_dead_parent/chronicle';D='/captures/dead_parent/chronicle';W='/reference_days/0/chronicle_pages/0'
rows=[]
def add(p,i,status,refs,note):rows.append({'id':f'P{p+1}-S{i+1:02}','review_json_pointer':f'/pages/{p}/direct_visible_statements/{i}','statement':review['pages'][p]['direct_visible_statements'][i],'status':status,'evidence':refs,'assessment':note})
def person(which):return {'file':'reference-data.json','json_pointer':f'/captures/{which}/person','fields':raw['captures'][which]['person']}
add(0,0,'NOT_VERIFIED',[person('living_dead_parent'),event(L,11)],'Age floor((85080-881)/1440)=58 and Elder event verified; current settlement and position need independent replay.')
add(0,1,'NOT_VERIFIED',[],'Current activity, target and inventory were not serialized in original capture; replay pending.')
add(0,2,'PASS',[person('living_dead_parent'),event(L,10)],'female=0; latest Paired other participant39=Bimuo/비무오; no subsequent pair/loss/death39 in world history through capture tick.')
add(0,3,'PASS',[person('living_dead_parent'),person('dead_parent')],'mother0=Nitiso/니티소; alive=false. English ellipsis remains a visual finding.')
add(0,4,'PASS',[person('living_dead_parent'),event(W,135)],'father1=Baho/바호; died at55740 before85080.')
add(0,5,'NOT_VERIFIED',[event(L,j) for j in [6,7,12]],'Children36,40,50 map to stated names. Exact current family count awaits raw family replay.')
for i,j in [(6,0),(7,1),(8,2),(9,4),(10,5),(11,6),(12,7),(13,9),(14,10),(15,11),(16,12)]:
 add(0,i,'PASS',[event(L,j)],'Event kind, participant roles, settlement where stated and derived day agree; deterministic names verified. Village-parent qualifier is a visible localized qualification, not a biological assertion.')
add(0,17,'PASS',[{'file':'living_dead_parent_en_top.png','basis':'screen-only presentation observation'}],'Labels/bars without numbers are presentation observations; no temperament numeric value asserted.')
add(1,0,'PASS',[person('dead_parent'),event(D,0),event(D,8)],'alive=false, founderkind1, died31800=>day23, cause3=old age.')
add(1,1,'PASS',[person('dead_parent'),event(D,5),event(W,135)],'female0; paired0+1; Baho death precedes capture.')
add(1,2,'PASS',[person('dead_parent')],'mother=-1 and father=-1.')
for i,j in [(3,0),(4,1),(5,2),(6,3),(7,4),(8,5),(9,6),(10,7),(11,8)]:add(1,i,'PASS',[event(D,j)],'Event roles/day/name agree; death age floor(81847/1440)=56 and cause3 where asserted.')
add(1,12,'PASS',[{'file':'dead_parent_en_top.png','basis':'screen-only presentation observation'}],'Labels/bars presentation only; no numerical temperament claim.')
for i,j in enumerate([184,183,182,180,178,177,176]):add(2,i,'FAIL' if i==6 else 'PASS',[event(W,j)],'Event participants/names/day/settlement agree; age floor(value/1440) and cause3 for deaths. Last partial birth subject54 maps to Ohuti/오후티, but reviewer wrote 오후디: FAIL for that statement; Village1/day57 agree, clipped parents are not inferred.')
clock=json.loads((capture/'living_dead_parent_en_top.json').read_text())['clock']
add(3,0,'PASS',[{'file':'living_dead_parent_en_top.json','json_pointer':'/clock','fields':clock}],'day_index59=>Day60; time10; season0=spring; day_of_season4. Daytime at10 corroborated.')
for i in [1,2,3]:add(3,i,'NOT_VERIFIED',[],'Original capture does not retain corresponding world HUD snapshots; screenshot reading alone is not independent raw verification. Replay pending.')
add(3,4,'PASS',[{'file':'living_dead_parent_en_top.png','basis':'screen-only presentation observation'}],'Empty panel is a visible observation, not a claim no historical village news exists.')
add(3,5,'PASS',[{'file':'living_dead_parent_en_top.png','basis':'screen-only presentation observation'},{'file':'dead_parent_ko_top.png','basis':'screen-only presentation observation'}],'Control labels/translations are presentation-only; no intervention execution or effect claimed.')
add(3,6,'NOT_VERIFIED',[{'file':'living_dead_parent_en_top.png','basis':'locale-mixing observation only'}],'Korean text in English is observable; factual resource quantities174,20,39 need replay.')
counts={s:sum(x['status']==s for x in rows) for s in ['PASS','FAIL','NOT_VERIFIED']}
obj={'schema':1,'reviewer_input':str(base/'life-review-round1.json'),'reviewer_input_sha256':sha(base/'life-review-round1.json'),'raw_input':str(capture/'reference-data.json'),'raw_sha256':sha(capture/'reference-data.json'),'scope':'Every direct_visible_statements item retained verbatim; inferences excluded, presentation-only statements explicitly separated from simulation facts. Original reader receives no key.','source_identity':{p:{'current_sha256':sha(root/p),'capture_sha256':raw['provenance']['sources']['res://'+p]} for p in ['scripts/ui/person_names.gd','scripts/ui/art_hash.gd']},'method':{'name_mapping':'Python equivalent of double ArtHash.mix +0x2545F491 xor, 46-syllable table, shared EN/KO blocklist, 46-attempt suffix carry; source SHA matches capture.','day':'floor((event.tick+world_info.clock_offset_ticks)/ticks_per_day)+1; offset480 tpd1440','age':'floor(event.value/1440) for death age; floor((capturetick-born_tick)/1440) for current age','event_enum':'Born0 Founder1 Paired2 Adult3 Elder4 Departed5 Widowed10 Died11; deathcause3 OldAge','script':str(base/'life/build_comparison.py')},'name_key':{str(i):names(i) for i in [0,1,7,12,25,26,27,28,29,30,31,32,35,36,39,40,48,49,50,53,54,55,56]},'statement_counts':counts,'h8':'FAIL','h8_reason':'Every non-inference statement must be correct. P3-S07 misreads 오후티 as 오후디; seven items retain uncorroborated live/world facts; no screenshot-only promotion to raw truth.','departures':{'days':list(range(60,91)),'status':'N/A','reason':'No kind5 Departed rows in the 31 actual day references; no four-cause occurrence or visual claim manufactured.'},'statements':rows,'excluded_inferences':[{'page':i+1,'statements':p['inferences']} for i,p in enumerate(review['pages'])],'visual_findings_retained':review['visual_findings'],'limitations':['Replay not yet run; original raw lacks live details/family and HUD snapshots.','PASS for presentation means observed visible wording/layout only, not runtime behavior.','Clipping, wrapping and English Korean resource labels retained as defects; no human interaction tested.']}
out=root/'docs/art/production11/life';out.mkdir(parents=True,exist_ok=True);(out/'reviewer-comparison.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
lines=['# 독립 생애 판독 대조','',f"H8: **FAIL**. 원문 45문장 중 PASS {counts['PASS']}, FAIL {counts['FAIL']}, NOT_VERIFIED {counts['NOT_VERIFIED']}. 추론은 점수에서 제외했다. 화면에 표시된 수치를 원본 사실로 대신 인정하지 않았다.",'','원본 판독: `life-review-round1.json`; 원본 사건: `life-attempt2/reference-data.json`. JSON 보고서에 각 원문, 배열 인덱스, 원시 필드 및 SHA-256을 보존했다. 이름 계산은 촬영 당시 SHA가 일치하는 PersonNames/ArtHash를 Python으로 동일 계산했다. 날짜는 `(tick+480)//1440+1`, 사망 나이는 `value//1440`이다.','','| 문장 | 판정 | 근거/제한 |','|---|---|---|']
for r in rows:lines.append(f"| {r['id']} | {r['status']} | {r['assessment']} |")
lines+=['','## 화면 판독 한계 유지','','영어 어머니 상태의 말줄임, 스크롤 가장자리 잘림, 한국어 이름 줄바꿈, 영어 화면의 한국어 식량·장작 표기를 그대로 남긴다. 라벨·빈 패널·버튼의 PASS는 화면 관찰에 한정하며 기능 동작이나 숫자 원본의 정확성을 뜻하지 않는다.','','60–90일 실제 31일 자료에 Departed 이벤트가 없으므로 네 이주 원인은 N/A이다. 임의 상태를 생성하지 않았다.','','독립 재현 스크립트는 저장됐으나 실행 전이다. 위치·행동·가족 수·자원·인구 등 미확인 항목은 재현 원본을 받은 뒤 갱신한다.']
(out/'reviewer-comparison.md').write_text('\n'.join(lines)+'\n')
print(counts);print(json.dumps(obj['name_key'],ensure_ascii=False))
