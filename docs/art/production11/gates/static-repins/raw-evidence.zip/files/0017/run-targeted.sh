#!/usr/bin/env bash
set -u
cd /Users/rexxa/work/new-world-art-prod || exit 1
out=/Users/rexxa/work/art-production11-evidence/static-repins
cutoff=$(date -j -u -f '%Y-%m-%dT%H:%M:%S' '2026-10-16T13:20:00' '+%s')
export CARGO_BUILD_JOBS=6
export CARGO_PROFILE_TEST_OPT_LEVEL=2
while read -r suite test_name; do
  while [[ -e /Users/rexxa/work/.mac_quiet.lock ]]; do
    printf '%s quiet-lock wait %s\n' "$(date -u '+%FT%TZ')" "$suite" >> "$out/targeted-events.log"
    [[ $(date '+%s') -ge $((cutoff - 600)) ]] && exit 0
    sleep 10
  done
  now=$(date '+%s')
  if [[ $now -ge $((cutoff - 600)) ]]; then
    printf '%s stopped: reserve 600sec before cutoff\n' "$(date -u '+%FT%TZ')" >> "$out/targeted-events.log"
    exit 0
  fi
  metadata="$out/$suite.metadata.txt"
  {
    date -u '+start=%FT%TZ'
    git rev-parse HEAD
    shasum -a 256 rust/target/debug/libsim_bridge.dylib
    printf 'CARGO_BUILD_JOBS=6 CARGO_PROFILE_TEST_OPT_LEVEL=2 cargo test --manifest-path rust/Cargo.toml -p sim-test --test %s %s -- --exact\n' "$suite" "$test_name"
  } > "$metadata"
  bash tools/art_pipeline/run_bounded.sh 600 cargo test --manifest-path rust/Cargo.toml -p sim-test --test "$suite" "$test_name" -- --exact > "$out/$suite.log" 2>&1
  result=$?
  elapsed=$(($(date '+%s') - now))
  {
    printf 'exit=%d\nelapsed_seconds=%d\n' "$result" "$elapsed"
    date -u '+end=%FT%TZ'
    git rev-parse HEAD
    shasum -a 256 rust/target/debug/libsim_bridge.dylib
  } >> "$metadata"
  printf '%s %s exit=%d elapsed=%ds\n' "$(date -u '+%FT%TZ')" "$suite" "$result" "$elapsed" | tee -a "$out/targeted-events.log"
  if [[ $result -ne 0 || $elapsed -ge 300 ]]; then
    printf 'stopped after failed or slow step; no further cargo launched\n' | tee -a "$out/targeted-events.log"
    exit "$result"
  fi
done <<'TESTS'
harness_p14_gamma_click_inspector harness_p14_gamma_a19_inspector_panel_hidden_until_display_agent
harness_p14_epsilon_activity_trails harness_p14_epsilon_a12_main_tscn_load_steps_equals_12
harness_p14_zeta_zoom_adaptive harness_zoom_a17_main_tscn_load_steps_equals_12
harness_show_agent_needs_bars harness_needs_a6_scene_wiring_additive
harness_show_death_visual harness_death_a6_scene_wiring_additive
TESTS
