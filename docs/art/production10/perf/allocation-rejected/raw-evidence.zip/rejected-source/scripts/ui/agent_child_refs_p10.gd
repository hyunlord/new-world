extends RefCounted
## Positive child references only; missing children are never negatively cached.
static var _by_sprite: Dictionary = {}
static var _enabled: bool = true

static func set_enabled(enabled: bool) -> void:
	_enabled = enabled
	_by_sprite.clear()

static func enabled() -> bool:
	return _enabled

static func forget(sprite: Sprite2D) -> void:
	_by_sprite.erase(sprite.get_instance_id())

static func find(sprite: Sprite2D, child_name: StringName) -> Sprite2D:
	if not _enabled:
		return sprite.get_node_or_null(NodePath(child_name)) as Sprite2D
	var id: int = sprite.get_instance_id()
	if not _by_sprite.has(id):
		_by_sprite[id] = {}
	var refs: Dictionary = _by_sprite[id]
	var cached: Variant = refs.get(child_name)
	if is_instance_valid(cached) and cached is Sprite2D and cached.get_parent() == sprite and cached.name == child_name:
		return cached as Sprite2D
	var child: Sprite2D = sprite.get_node_or_null(NodePath(child_name)) as Sprite2D
	if child == null:
		refs.erase(child_name)
	else:
		refs[child_name] = child
	return child
