extends RefCounted
## Compare only values with copy semantics; always replace collection/object metadata.
static var _enabled: bool = true

static func set_enabled(enabled: bool) -> void:
	_enabled = enabled

static func enabled() -> bool:
	return _enabled

static func set_value(owner: Object, key: StringName, value: Variant) -> void:
	if _enabled:
		match typeof(value):
			TYPE_BOOL, TYPE_INT, TYPE_STRING, TYPE_STRING_NAME, TYPE_VECTOR2I:
				if owner.has_meta(key):
					var previous: Variant = owner.get_meta(key)
					if typeof(previous) == typeof(value) and previous == value:
						return
	owner.set_meta(key, value)
