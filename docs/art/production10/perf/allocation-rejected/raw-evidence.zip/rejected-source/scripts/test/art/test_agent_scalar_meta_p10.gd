extends SceneTree
const Meta = preload("res://scripts/ui/agent_scalar_meta_p10.gd")

func _initialize() -> void:
	var owner := Node.new()
	for enabled: bool in [false, true]:
		Meta.set_enabled(enabled)
		assert(Meta.enabled() == enabled)
		for value: Variant in [true, false, 1, 2, "a", "b", &"a", Vector2i(1, 2), Vector2i(2, 3), 1.5, Vector2(1, 2), Color.RED]:
			Meta.set_value(owner, &"value", value)
			Meta.set_value(owner, &"value", value)
			assert(typeof(owner.get_meta("value")) == typeof(value))
			assert(owner.get_meta("value") == value)
		Meta.set_value(owner, &"typed", 1)
		Meta.set_value(owner, &"typed", 1.0)
		assert(typeof(owner.get_meta("typed")) == TYPE_FLOAT)
		Meta.set_value(owner, &"typed", "a")
		Meta.set_value(owner, &"typed", &"a")
		assert(typeof(owner.get_meta("typed")) == TYPE_STRING_NAME)
		var old_dict: Dictionary = {"x": 1}
		var new_dict: Dictionary = {"x": 1}
		Meta.set_value(owner, &"dict", old_dict)
		Meta.set_value(owner, &"dict", new_dict)
		new_dict["x"] = 2
		old_dict["x"] = 3
		assert(owner.get_meta("dict")["x"] == 2)
		var old_array: Array = [1]
		var new_array: Array = [1]
		Meta.set_value(owner, &"array", old_array)
		Meta.set_value(owner, &"array", new_array)
		new_array[0] = 2
		old_array[0] = 3
		assert(owner.get_meta("array")[0] == 2)
		Meta.set_value(owner, &"zero", 0.0)
		Meta.set_value(owner, &"zero", -0.0)
		assert(var_to_bytes(owner.get_meta("zero")) == var_to_bytes(-0.0))
		Meta.set_value(owner, &"value", null)
		assert(not owner.has_meta("value"))
	owner.free()
	print("P10 scalar metadata type and alias checks passed")
	quit(0)
