extends SceneTree
const Refs = preload("res://scripts/ui/agent_child_refs_p10.gd")

func _initialize() -> void:
	var sprite := Sprite2D.new()
	root.add_child(sprite)
	Refs.set_enabled(true)
	assert(Refs.find(sprite, &"CarryLoad") == null)
	var first := Sprite2D.new()
	first.name = "CarryLoad"
	first.set_meta("art_id", 3)
	sprite.add_child(first)
	assert(Refs.find(sprite, &"CarryLoad") == first)
	assert(Refs.find(sprite, &"CarryLoad") == first)
	first.name = "RetiredName"
	assert(Refs.find(sprite, &"CarryLoad") == null)
	first.name = "CarryLoad"
	assert(Refs.find(sprite, &"CarryLoad") == first)
	sprite.remove_child(first)
	assert(Refs.find(sprite, &"CarryLoad") == null)
	sprite.add_child(first)
	Refs.forget(sprite)
	sprite.set_meta("art_id", 9)
	assert(Refs.find(sprite, &"CarryLoad") == first)
	assert(first.get_meta("art_id") == 3) # Preserve existing pooling metadata behavior exactly.
	first.free()
	assert(Refs.find(sprite, &"CarryLoad") == null)
	var replacement := Sprite2D.new()
	replacement.name = "CarryLoad"
	sprite.add_child(replacement)
	assert(Refs.find(sprite, &"CarryLoad") == replacement)
	Refs.set_enabled(false)
	assert(Refs.find(sprite, &"CarryLoad") == replacement)
	Refs.forget(sprite)
	sprite.free()
	print("P10 child reference lifetime checks passed")
	quit(0)
