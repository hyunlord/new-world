extends SceneTree
const Meta = preload("res://scripts/ui/agent_scalar_meta_p10.gd")
const Children = preload("res://scripts/ui/agent_child_refs_p10.gd")
func _init() -> void:
	var sprite := Sprite2D.new()
	var child := Sprite2D.new()
	child.name = "CarryLoad"
	sprite.add_child(child)
	sprite.set_meta("test", 42)
	Children.find(sprite, &"CarryLoad")
	for sample: int in range(4):
		var start: int = Time.get_ticks_usec()
		for i: int in range(100000):
			sprite.set_meta("test", 42)
		var native_meta: int = Time.get_ticks_usec() - start
		Meta.set_enabled(true)
		start = Time.get_ticks_usec()
		for i: int in range(100000):
			Meta.set_value(sprite, &"test", 42)
		var cached_meta: int = Time.get_ticks_usec() - start
		Meta.set_enabled(false)
		start = Time.get_ticks_usec()
		for i: int in range(100000):
			Meta.set_value(sprite, &"test", 42)
		var disabled_meta: int = Time.get_ticks_usec() - start
		start = Time.get_ticks_usec()
		for i: int in range(100000):
			var found: Sprite2D = sprite.get_node_or_null("CarryLoad") as Sprite2D
		var native_child: int = Time.get_ticks_usec() - start
		Children.set_enabled(true)
		start = Time.get_ticks_usec()
		for i: int in range(100000):
			var found: Sprite2D = Children.find(sprite, &"CarryLoad")
		var cached_child: int = Time.get_ticks_usec() - start
		Children.set_enabled(false)
		start = Time.get_ticks_usec()
		for i: int in range(100000):
			var found: Sprite2D = Children.find(sprite, &"CarryLoad")
		print(JSON.stringify({"sample": sample, "iterations":100000,"native_meta_usec":native_meta,"cached_meta_usec":cached_meta,"disabled_meta_usec":disabled_meta,"native_child_usec":native_child,"cached_child_usec":cached_child,"disabled_child_usec":Time.get_ticks_usec()-start}))
	Children.forget(sprite)
	sprite.free()
	quit(0)
