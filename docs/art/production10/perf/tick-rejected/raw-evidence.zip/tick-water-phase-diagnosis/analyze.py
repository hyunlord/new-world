"""Offline original-attempt water attribution; does not alter capture evidence."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
from PIL import Image

EVIDENCE = Path('/Users/rexxa/work/art-production10-evidence')
REPO = Path('/Users/rexxa/work/new-world-art-prod')
OUT = Path(__file__).parent
INPUTS = {
    'baseline_png': EVIDENCE / 'identity/baseline/A/P5.png',
    'candidate_png': EVIDENCE / 'tick-cache-attempt1/B/P5.png',
    'baseline_json': EVIDENCE / 'identity/baseline/A/P5.json',
    'candidate_json': EVIDENCE / 'tick-cache-attempt1/B/P5.json',
    'original_comparison': EVIDENCE / 'tick-cache-attempt1/comparison/comparison.json',
    'water_atlas': REPO / 'assets/art/terrain/water.png',
    'terrain_manifest': REPO / 'assets/art/terrain/terrain_manifest.json',
    'terrain_renderer': REPO / 'scripts/ui/terrain_renderer.gd',
    'season_tint': REPO / 'scripts/ui/art_season_tint.gd',
}

def main() -> None:
    a = Image.open(INPUTS['baseline_png']).convert('RGB')
    b = Image.open(INPUTS['candidate_png']).convert('RGB')
    atlas = Image.open(INPUTS['water_atlas']).convert('RGBA')
    am = json.loads(INPUTS['baseline_json'].read_text())
    bm = json.loads(INPUTS['candidate_json'].read_text())
    assert a.size == b.size == (1920, 1080)
    assert am == bm
    assert am['camera'] == [1016.0, 500.0] and am['zoom'] == 4
    water = next(x for x in json.loads(INPUTS['terrain_manifest'].read_text())['layers'] if x['name'] == 'water')
    assert all(x['frames'] == 4 and x['fps'] == 3 for x in water['tiles'])
    # Observed RGB values correspond to atlas colors under the source spring tint.
    # Explicit mapping avoids platform-dependent float-to-UNORM rounding assumptions.
    colors = {(47, 92, 133): (46, 92, 126), (43, 91, 114): (42, 91, 108)}
    pairs: Counter = Counter()
    scores = [Counter(), Counter()]
    changed = []
    for y in range(a.height):
        for x in range(a.width):
            av, bv = a.getpixel((x, y)), b.getpixel((x, y))
            if av == bv:
                continue
            pairs[(av, bv)] += 1
            changed.append((x, y))
            # TileMapLayer origin = SPRITE_ORIGIN(448,28) - (8,8).
            wx = (x - a.width / 2) / am['zoom'] + am['camera'][0] - 440
            wy = (y - a.height / 2) / am['zoom'] + am['camera'][1] - 20
            tx, ty = math.floor(wx / 16), math.floor(wy / 16)
            lx, ly = math.floor(wx) % 16, math.floor(wy) % 16
            variant = (((tx * 73856093) ^ (ty * 19349663)) & 0x7fffffff) % 4
            # Waves are shared by mask rows. Row15 is the complete water tile.
            for side, pixel in enumerate((av, bv)):
                for frame in range(4):
                    source = atlas.getpixel(((variant * 4 + frame) * 16 + lx, 15 * 16 + ly))
                    if colors.get(source[:3]) == pixel:
                        scores[side][frame] += 1
    result = {
        'scope': 'Original attempt1 P5 only. Offline attribution, not a rerun or acceptance verdict.',
        'inputs': {name: {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in INPUTS.items()},
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'manifests_equal': am == bm,
        'changed_pixels': len(changed),
        'changed_bounds_inclusive': [min(x for x,y in changed), min(y for x,y in changed), max(x for x,y in changed), max(y for x,y in changed)],
        'color_pairs': [{'A': list(key[0]), 'B': list(key[1]), 'count': value} for key,value in sorted(pairs.items())],
        'changed_pixels_matching_atlas_frame': {'A': dict(sorted(scores[0].items())), 'B': dict(sorted(scores[1].items()))},
        'interpretation': 'Every changed pixel matches baseline water frame2 and candidate water frame0. The difference is water phase, not visible agent/chill pixels.',
        'limitations': 'Attribution covers changed pixels; it does not recover all hidden tile masks, establish why the engine selected different phases, or prove tick-cache equivalence in running scenes. No baseline, harness, threshold or source was changed.',
    }
    assert len(changed) == 1680 and scores[0][2] == 1680 and scores[1][0] == 1680
    assert len(pairs) == 2
    (OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'changed_pixels': len(changed), 'matching_frames': result['changed_pixels_matching_atlas_frame'], 'manifests_equal': am == bm}))

if __name__ == '__main__':
    main()
