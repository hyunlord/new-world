# Original tick attempt1: P5 water-phase diagnosis

Offline analysis reproduced 1,680 changed pixels, with identical A/B capture manifests. Every changed baseline pixel matches water atlas frame 2; every changed candidate pixel matches frame 0 after camera projection, deterministic tile variant selection and the observed spring-tinted palette mapping.

Only two color swaps occur:

| A RGB | B RGB | Pixels |
| --- | --- | ---: |
| 46,92,126 | 42,91,108 | 864 |
| 42,91,108 | 46,92,126 | 816 |

The source water tiles have four frames at 3 FPS. `scripts/ui/terrain_renderer.gd:34–37` configures that animation. The script uses the full water mask row for wave matching; it attributes changed pixels, rather than reconstructing hidden tile masks or the entire scene. It does not establish why the renderer selected different animation phases.

Reproduce with Pillow available:

```sh
python3 /Users/rexxa/work/art-production10-evidence/tick-water-phase-diagnosis/analyze.py
```

`result.json` records exact input paths and SHA256 hashes, script hash, pixel bounds, color counts and frame-match counts. Missing frame keys mean zero matching changed pixels. Check those hashes when reproducing against later filesystem state.

The original all-six capture failure remains a failure. This diagnosis does not replace or revise its verdict, baseline, harness, thresholds or source. The parent owns the separate P5-only retry and any subsequent running checks; this artifact does not claim the retry result or reassign the other five captures to different source bytes. No Godot or Cargo runtime was launched here.
