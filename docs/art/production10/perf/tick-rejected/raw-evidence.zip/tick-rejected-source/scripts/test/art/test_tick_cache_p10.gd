extends SceneTree

const Renderer = preload("res://scripts/ui/agent_renderer.gd")
const Reads = preload("res://scripts/ui/sim_reads.gd")
const Activity = preload("res://scripts/ui/agent_activity.gd")
var failures: int = 0
var checks: int = 0

class FakeWorld extends Node:
	signal world_reset
	var tick: int = 10
	func advance_ticks(count: int) -> int:
		tick += count
		return tick
	func apply_intervention(_kind: String, _settlement: int, _amount: int) -> Dictionary:
		return {}
	func on_building_placed(_x: int, _y: int, _radius: int) -> bool:
		return false
	func reset_world(_seed: int) -> bool:
		tick = 10
		return true
	func reset_world_stress(_seed: int, _count: int) -> bool:
		tick = 10
		return true

func _initialize() -> void:
	call_deferred("_run")

func check(condition: bool, label: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error(label)

func _run() -> void:
	var host := Node.new()
	root.add_child(host)
	var world := FakeWorld.new()
	world.name = "WorldSim"
	host.add_child(world)
	check(Reads.tick_cache_key(world, {"tick": 10}).is_empty(), "missing reader bypass")
	var reader := Reads.new()
	reader.name = "SimReads"
	host.add_child(reader)
	var initial: Array = Reads.tick_cache_key(world, {"tick": 10})
	check(initial.size() == 5, "complete cache key")
	check(initial == Reads.tick_cache_key(world, {"tick": 10}), "same key stable")
	check(Reads.tick_cache_key(world, {}).is_empty(), "missing tick bypass")
	var arguments: Dictionary = {
		"apply_intervention": ["food", 1, 2], "advance_ticks": [0],
		"reset_world": [1], "reset_world_stress": [1, 2],
		"on_building_placed": [1, 1, 2],
	}
	for method: String in Reads.MUTATORS:
		var before: Array = Reads.tick_cache_key(world, {"tick": 10})
		Reads.mutate(world, method, arguments[method])
		var after: Array = Reads.tick_cache_key(world, {"tick": 10})
		check(int(after[3]) == int(before[3]) + 1, method + " increments even same-tick/false-return")
	var before_signal: Array = Reads.tick_cache_key(world, {"tick": 10})
	world.world_reset.emit()
	var after_signal: Array = Reads.tick_cache_key(world, {"tick": 10})
	check(int(after_signal[4]) == int(before_signal[4]) + 1, "reset signal generation")
	check(after_signal != Reads.tick_cache_key(world, {"tick": 11}), "natural simulation tick")
	var renderer := Renderer.new()
	check(renderer._begin_tick_cache(after_signal), "enable tick cache")
	renderer._tick_rows[5] = {"sentinel": true}
	check(renderer._begin_tick_cache(after_signal) and renderer._tick_rows.has(5), "same key reuses")
	var next: Array = after_signal.duplicate()
	next[3] = int(next[3]) + 1
	check(renderer._begin_tick_cache(next) and renderer._tick_rows.is_empty(), "mutation invalidates")
	for index: int in range(5):
		renderer._tick_tiles[Vector2i.ZERO] = {"sentinel": true}
		var changed: Array = next.duplicate()
		changed[index] = int(changed[index]) + 1
		check(renderer._begin_tick_cache(changed) and renderer._tick_tiles.is_empty(), "key dimension %d invalidates" % index)
		renderer._begin_tick_cache(next)
	renderer.set_perf_candidate_p10("tick-only-cache", false)
	check(not renderer._begin_tick_cache(next), "disabled bypass")
	check(renderer._allocation_candidate and renderer._selection_lookup_enabled, "tick control retains allocation defaults")
	renderer.set_perf_candidate_p10("tick-only-cache", true)
	check(not renderer._begin_tick_cache([]), "unavailable key bypass")
	check(renderer._allocation_candidate and renderer._selection_lookup_enabled, "tick candidate retains allocation defaults")
	var context: Dictionary = {"hearths": [Vector2i(-4, -2), Vector2i(7, 8)], "shelters": {Vector2i(3, -1): true}, "sites": {}, "food": {}, "wood": {}, "terrain": {}}
	var indexed: Dictionary = context.duplicate(true)
	renderer._index_camp_tiles(indexed)
	for y: int in range(-8, 13):
		for x: int in range(-10, 13):
			var tile := Vector2i(x, y)
			check(renderer._tile_context(tile, context) == renderer._tile_context(tile, indexed), "indexed tile %s" % tile)
	for state: int in range(5):
		for target: int in range(-1, 9):
			for wood: int in range(2):
				for carried: float in [0.0, 2.0]:
					for tile: Dictionary in [{}, {"wood": true}, {"shelter": true}, {"construction": true}, {"food": true}, {"water": true}]:
						var still: String = Activity.resolve(state, target, target >= 0, false, carried, tile, 12.0, wood)
						var moving: String = Activity.resolve(state, target, target >= 0, true, carried, tile, 12.0, wood)
						for is_moving: bool in [true, false, true, false]:
							check((moving if is_moving else still) == Activity.resolve(state, target, target >= 0, is_moving, carried, tile, 12.0, wood), "moving-bit differential")
	renderer.free()
	host.free()
	print("tick_cache_p10 checks=%d failures=%d" % [checks, failures])
	quit(0 if failures == 0 else 1)
