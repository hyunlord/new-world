import os,signal,subprocess,time,json
from pathlib import Path
out=Path('/Users/rexxa/work/art-production10-evidence/activity-probe-prep')
command='bash '+str(out/'run.sh')
def processes():
 rows={}
 for line in subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines():
  values=line.strip().split(None,2)
  if len(values)==3: rows[int(values[0])]=(int(values[1]),values[2])
 return rows
initial=processes(); matches=[pid for pid,(_,cmd) in initial.items() if cmd==command]
assert len(matches)==1,matches
root=matches[0]
while True:
 rows=processes()
 if root not in rows or rows[root][1]!=command: break
 lock=Path('/Users/rexxa/work/.mac_quiet.lock')
 reason='quiet_lock_appeared' if lock.exists() else ('preparation_deadline' if time.time()>=1792096800 else '')
 if reason:
  owned={root}
  while True:
   found={pid for pid,(parent,_) in rows.items() if parent in owned}
   new=owned|found
   if new==owned:break
   owned=new
  out.joinpath('watch-abort.json').write_text(json.dumps({'reason':reason,'pids':sorted(owned),'time':time.time()})+'\n')
  for sig in (signal.SIGTERM,signal.SIGKILL):
   for pid in sorted(owned,reverse=True):
    try:os.kill(pid,sig)
    except ProcessLookupError:pass
   time.sleep(1)
  break
 time.sleep(5)
print('probe preparation watcher finished')
