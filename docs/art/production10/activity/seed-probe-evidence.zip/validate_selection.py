from pathlib import Path
import hashlib,json,re,datetime
root=Path(__file__).parent
repo=Path('/Users/rexxa/work/new-world-art-prod')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
errors=[]
exit_code=int((root/'probe.exit').read_text());build_exit=int((root/'build.exit').read_text());head=(root/'head.txt').read_text().strip()
expected_hash,binary_path=(root/'binary.sha256').read_text().strip().split(maxsplit=1)
actual_hash=sha(repo/binary_path)
if build_exit!=0: errors.append('build exit nonzero')
if actual_hash!=expected_hash: errors.append('binary hash drift')
source_mismatches=[];source_count=0
for line in (root/'rust-sources.sha256').read_text().splitlines():
 h,p=line.split(maxsplit=1); source_count+=1
 if not (repo/p).is_file() or sha(repo/p)!=h: source_mismatches.append(p)
if source_mismatches: errors.append('Rust source hashes changed since build manifest')
summary_path=root/'results/summary.json';summary=json.loads(summary_path.read_text()) if summary_path.exists() else None
expected=list(range(20261011,20261027)); markers=[int(x) for x in re.findall(r'^PROBE seed=(\d+) shelter_plan_skips=\d+$',(root/'probe.log').read_text(),re.M)]
if summary is not None:
 if summary['seeds']!={'start':20261011,'end_exclusive':20261027}: errors.append('summary seed range mismatch')
 if summary['scene']!='game_v22': errors.append('summary scene mismatch')
 summary_runs={r['seed']:r for r in summary['runs']}
 if len(summary_runs)!=len(summary['runs']): errors.append('summary duplicate runs')
 if sorted(summary_runs)!=expected: errors.append('summary run seeds mismatch')
else: summary_runs={}
rows=[]; incomplete=[];files={}
for seed in expected:
 p=root/f'results/game_v22_s{seed}.jsonl'
 if not p.exists(): incomplete.append(seed);continue
 files[str(p.relative_to(root))]=sha(p)
 data=[];parse_errors=[]
 for line_number,line in enumerate(p.read_text().splitlines(),1):
  try: data.append((line_number,json.loads(line)))
  except ValueError: parse_errors.append(line_number)
 endpoint=[(n,x) for n,x in data if x.get('sample_kind')=='day' and x.get('tick')==86400 and x.get('day')==60]
 clocks=[(n,x) for n,x in data if x.get('sample_kind')=='clock' and x.get('tick')==85080 and x.get('minute_of_day')==600]
 days=[x for _,x in data if x.get('sample_kind')=='day']
 complete=len(endpoint)==1 and len(clocks)==1 and markers.count(seed)==1 and not parse_errors
 if not complete: incomplete.append(seed); continue
 if sorted(x['tick'] for x in days)!=list(range(1440,86401,1440)): errors.append(f'{seed}: daily records not complete 60')
 if any(x.get('seed')!=seed or x.get('scene')!='game_v22' or x.get('git_sha')!=head for _,x in data): errors.append(f'{seed}: row identity mismatch')
 end_line,end=endpoint[0]; clock_line,clock=clocks[0]
 if abs(clock['day']-59.083333333333336)>1e-10: errors.append(f'{seed}: clock elapsed day mismatch')
 run=summary_runs.get(seed)
 if summary is not None and (run is None or len(run['alive_daily'])!=60 or run['alive_daily'][59]!=end['alive']): errors.append(f'{seed}: summary endpoint mismatch')
 rows.append({'seed':seed,'endpoint_tick':86400,'endpoint_elapsed_day':60,'endpoint_alive':end['alive'],'capture_tick':85080,'capture_calendar_day':60,'capture_hour':10,'capture_elapsed_day':clock['day'],'capture_alive':clock['alive'],'capture_settlements':clock['settlements'],'endpoint_line':end_line,'clock_line':clock_line,'jsonl':str(p.relative_to(root)),'sha256':files[str(p.relative_to(root))]})
if exit_code==0 and (incomplete or len(rows)!=16 or sorted(markers)!=expected):errors.append('exit0 without complete 16-seed evidence')
if exit_code not in (0,124):errors.append(f'probe terminal error {exit_code}')
rows.sort(key=lambda r:(-r['endpoint_alive'],r['seed']))
for p in sorted((root/'results').iterdir()):
 if p.is_file():files[str(p.relative_to(root))]=sha(p)
result={'schema_version':1,'valid':not errors,'errors':errors,'probe_exit':exit_code,'build_exit':build_exit,'timed_out':exit_code==124,'requested_seeds':expected,'completed_seeds':sorted(r['seed'] for r in rows),'incomplete_seeds':incomplete,'ranking_rule':'maximum alive at sample_kind=day, day=60, tick=86400; ties minimum seed','capture_rule':'calendar day60 10:00 = tick85080; sample_kind=clock, minute_of_day=600; population separate from ranking endpoint','winner':rows[0] if rows and not errors else None,'ranking':rows,'git_sha':head,'binary':{'path':binary_path,'recorded_sha256':expected_hash,'current_sha256':actual_hash,'match':actual_hash==expected_hash},'rust_source_manifest':{'sha256':sha(root/'rust-sources.sha256'),'files':source_count,'mismatches':source_mismatches},'artifact_sha256':files,'summary_sha256':sha(summary_path) if summary_path.exists() else None,'probe_log_sha256':sha(root/'probe.log')}
(root/'selection.json').write_text(json.dumps(result,indent=2)+'\n')
md=['# Day60 activity capture seed selection','',f'Validation: {"PASS" if result["valid"] else "FAIL"}. Build exit {build_exit}; probe exit {exit_code}; {len(rows)}/16 completed seeds.','',f'Ranking uses day60 endpoint tick86400; capture uses calendar day60 10:00 tick85080. They are separate population measurements.','']
if result['winner']:
 w=result['winner'];md += [f'Winner: **{w["seed"]}**; endpoint population **{w["endpoint_alive"]}**, capture-time population **{w["capture_alive"]}**, capture-time settlements **{w["capture_settlements"]}**.','']
md+=['| Rank | Seed | Endpoint population (86400) | Capture population (85080) |','|---|---|---|---|']
for rank,r in enumerate(rows,1):md.append(f'| {rank} | {r["seed"]} | {r["endpoint_alive"]} | {r["capture_alive"]} |')
md+=['',f'Binary SHA256 `{actual_hash}` matches pre-run record. Rust source manifest checked: {source_count} files, {len(source_mismatches)} mismatches.',f'Summary SHA256 `{result["summary_sha256"]}`. All output hashes and exact selected JSONL line numbers are in selection.json.',f'Git source identity `{head}`. All parsed per-seed rows checked against this identity.', '', 'No probe was relaunched. This selects the seed from native headless simulation; Godot capture and visual/pose validation are not established by this result.']
if errors:md+=['','Errors: '+repr(errors)]
(root/'selection.md').write_text('\n'.join(md)+'\n')
print(json.dumps({k:result[k] for k in ['valid','errors','probe_exit','completed_seeds','winner','binary','rust_source_manifest']},indent=2))
