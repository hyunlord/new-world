#!/usr/bin/env bash
set -euo pipefail
cd /Users/rexxa/work/new-world-art-prod
out=/Users/rexxa/work/art-production10-evidence/activity-probe-prep
[[ ! -d /Users/rexxa/work/.mac_quiet.lock ]] || exit 75
git rev-parse HEAD > "$out/head.txt"
git ls-files rust | while IFS= read -r file; do shasum -a 256 "$file"; done > "$out/rust-sources.sha256"
rc=0
CARGO_BUILD_JOBS=6 bash tools/art_pipeline/run_bounded.sh 900 cargo build --manifest-path rust/Cargo.toml -p sim-test --bin worldsim_probe --release > "$out/build.log" 2>&1 || rc=$?
printf '%s\n' "$rc" > "$out/build.exit"
[[ "$rc" == 0 ]] || exit "$rc"
shasum -a 256 rust/target/release/worldsim_probe > "$out/binary.sha256"
[[ ! -d /Users/rexxa/work/.mac_quiet.lock ]] || exit 75
remaining=$((1792096800-$(date +%s)))
(( remaining > 0 )) || exit 124
(( remaining > 1800 )) && remaining=1800
printf '%s\n' "$remaining" > "$out/probe-limit.txt"
rc=0
WORLDSIM_GIT_SHA=$(cat "$out/head.txt") bash tools/art_pipeline/run_bounded.sh "$remaining" rust/target/release/worldsim_probe --scene game_v22 --seeds 20261011..20261027 --days 60 --workers 4 --clock-samples 10:00 --out "$out/results" > "$out/probe.log" 2>&1 || rc=$?
printf '%s\n' "$rc" > "$out/probe.exit"
exit "$rc"
