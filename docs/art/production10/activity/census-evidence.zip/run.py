import json,os,signal,subprocess,time
from pathlib import Path
p=Path(__file__).parent
results=[]
for label,seed,day,minute in [('day60-1000',20261018,60,600),('day30-1500',20261010,30,900)]:
 if Path('/Users/rexxa/work/.mac_quiet.lock').exists():raise SystemExit('quiet lock present; census not launched')
 env=dict(os.environ,P10_BASELINE_OUT=str(p/(label+'.json')))
 cmd=['/Users/rexxa/Downloads/Godot.app/Contents/MacOS/Godot','--headless','--path','/Users/rexxa/work/new-world-art-prod','--script',str(p/'probe.gd'),'--','--mode=live',f'--seed={seed}',f'--day={day}',f'--minute={minute}']
 started=time.time();reason=None
 with (p/(label+'.log')).open('w') as stream:
  child=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  while child.poll() is None:
   if Path('/Users/rexxa/work/.mac_quiet.lock').exists() or time.time()-started>900:
    reason='quiet lock appeared' if Path('/Users/rexxa/work/.mac_quiet.lock').exists() else '900s limit'
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    break
   time.sleep(1)
  code=child.wait()
 row={'label':label,'command':cmd,'exit':code,'reason':reason,'elapsed':time.time()-started};results.append(row)
 (p/(label+'.exit')).write_text(str(code)+'\n');(p/'launches.json').write_text(json.dumps(results,indent=2)+'\n');print(row,flush=True)
 if code:raise SystemExit(1)
