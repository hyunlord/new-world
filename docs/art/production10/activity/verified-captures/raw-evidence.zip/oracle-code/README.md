# External H7 evidence checker draft

No repository sources modified, no Godot/build/captures launched. Offline fixtures are synthetic test data, never visual evidence. This checker does not call production `choose_frame`, Activity, or Godot. It independently evaluates the GOAL6.2 chains, body identity hash, directional targets, actual atlas availability, frame animation index, mirroring, and override precedence. It checks every raw holder, including hidden and offscreen holders; missing/duplicate holders and absent input fields fail closed.

Files:
- `activity_rules.py`: independent chains and frame selection; reads actual atlas, suppression, acceptance, basket/bush restrictions, and cold audit RGBA hashes using the repository's existing Pillow dependency.
- `check_activity_sidecars.py`: raw entity-bit/agent-ID join, raw-place/building/home facing, pose/body/view/frame/texture/region validation, ordered applied overrides, hidden/viewport validation. Reuses the existing scaffold structural validator only. A sidecar/image/atlas/audit SHA256 binding accompanies each CLI report.
- `prepare_blind_crops.py`: real-image inventory, two crops per kind, centered square context crops, exactly 4x nearest scaling. Missing kinds or failed sidecar checks exit nonzero with inventory/error evidence. No fabricated holders or crops. `--extract` is opt-in and was not executed.
- `renderer-oracle-inputs.patch`: bounded instrumentation against the external activity renderer draft. Adds observed animation time, previous facing, movement, pickup/meal booleans, chill alpha, capture/parent visibility. These are inputs, never expected-pose answers.
- `capture-oracle-inputs.patch`: require the input metadata and emit raw building/society snapshots via ReadRoute. Patch bindings identify exact input sources; rebase after accepted Part1 rather than copying older full renderer code.

## Future commands (after integration and authorized captures)

```
python3 check_activity_sidecars.py /Users/rexxa/work/new-world-art-prod CAPTURE/capture.json ... > oracle-report.json
python3 prepare_blind_crops.py /Users/rexxa/work/new-world-art-prod NEW_REVIEW_DIRECTORY CAPTURE/capture.json ... --extract
```

Use all six required captures. These tools check each provided capture; the existing six-case runner remains responsible for cohort completeness, populous-world selection evidence, exact requested framing, source provenance, fixed-delta launch, and quiet/deadline protocols. Do not claim the entire required cohort from a subset. The crop output is new-directory-only. Give the fresh blind reviewer only `blind/` (neutral filenames and seven choices); keep `key.json` separate, save reviewer answers first, then reveal key and compute accuracy. No blind score or pass bar is invented.

## Explicit limits / required review

- `pose_check_complete=true` means this individual sidecar passed the implemented check; `h7_pass` always remains false and blind review pending. Capture files retain `pose_oracle_checked=false`; checker emits a separate report and never rewrites evidence.
- Activity holders in non-activity states other than sleeping are an explicit unsupported condition and fail closed. If real captures contain one, extend the independent state/facing rules with a focused test from its evidence before acceptance; never omit that holder.
- Pickup/meal/chill inputs are temporal renderer observations because a single raw tick cannot reconstruct their histories. The checker verifies their precedence and exact override list, not the upstream temporal detector. Independent detector tests remain necessary if that implementation changes.
- Home facing mirrors the reviewed draft's actual home formation hearth preference, then geometric nearest fallback. This does not prove settlement ownership of fallback buildings. Review the fallback against the GOAL before H7 if ownership evidence requires a stricter mapping.
- Hidden, offscreen, and near-edge holders remain checked but cannot be invented as blind crops. Crop inventory is honest about shortages. Two images of one holder at different capture framings can qualify as two real crops; prefer diversity during review selection if enough candidates exist.
- Pixel perception and identity accuracy require actual captures and a fresh human/agent reviewer. A correct metadata result cannot substitute for visual review.

## Offline verification

`python3 -m unittest discover -s /Users/rexxa/work/art-production10-evidence/activity-oracle-draft -p 'test_*.py'`

15 tests pass, including the 168-case kind/body/view/phase matrix (336 assertions) against current atlas; missing fields, wrong body/view/sprite/region, raw facing change, duplicate/absent holders, hidden/offscreen checking, cold and chill lists, pickup+meal precedence, sheltered sleep, unsupported state failure, and 14-crop/missing-kind inventory. Python compileall passed. No actual sidecars were certified.
